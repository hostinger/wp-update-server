export namespace Route {
  export enum Base {
    HOSTINGER_TOOLS = 'hostinger-tools',
  }
}
