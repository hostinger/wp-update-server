export const STORE_PERSISTENT_KEYS = {
  TOOLS_GENERAL_DATA_STORE: "tools-general-data-store",
  SETTINGS_STORE: "settings-store",
} as const;
