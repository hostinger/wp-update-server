<?php

class Hostinger_Onboarding_Setup_Store extends Hostinger_Onboarding_Step {
	public function get_title(): string {
		return __( 'Set up your online store', 'hostinger' );
	}

	public function get_body(): array {
		ob_start();

		?>

		<?php echo __( 'Complete this following steps to set up your online store. Don\'t worry, WooCommerce will help you to finish the steps.', 'hostinger' ); ?>
		<ul>
			<li>
				<?php echo __( 'Add products', 'hostinger' ); ?>
			</li>
			<li>
				<?php echo __( 'Set up payments', 'hostinger' ); ?>
			</li>
			<li>
				<?php echo __( 'Stock management (if needed)', 'hostinger' ); ?>
			</li>
			<li>
				<?php echo __( 'Add tax rates (if needed)', 'hostinger' ); ?>
			</li>
			<li>
				<?php echo __( 'Advertising configuration (if needed)', 'hostinger' ); ?>
			</li>
		</ul>
		<?php

		$description = ob_get_contents();

		ob_end_clean();

		return [
			[
				'description' => $description
			],
		];
	}

	public function step_identifier(): string {
		return 'setup_store';
	}

	public function get_redirect_link(): string {
		return admin_url( 'admin.php?page=wc-admin&path=' . rawurlencode('/setup-wizard') );
	}

	public function button_text(): string {
		return __( 'Set up store', 'hostinger' );
	}
}
