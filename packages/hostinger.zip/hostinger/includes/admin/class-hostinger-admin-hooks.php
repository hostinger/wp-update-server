<?php

defined( 'ABSPATH' ) || exit;

class Hostinger_Admin_Hooks {
	private $settings;
	private $helper;

	public function __construct() {
		$this->settings = new Hostinger_Settings();
		$this->helper   = new Hostinger_Helper();

		add_action( 'admin_footer', array( $this, 'rate_plugin' ) );
		add_action( 'admin_init', array( $this, 'hide_astra_builder_selection_screen' ) );

	}

	public function rate_plugin(): void {
		$promotional_banner_hidden = get_transient( 'hts_hide_promotional_banner_transient' );
		$two_hours_in_seconds      = 7200;

		if ( $promotional_banner_hidden && time() > $promotional_banner_hidden + $two_hours_in_seconds ) {
			require_once HOSTINGER_ABSPATH . 'includes/admin/views/partials/hostinger-rate-us.php';
		}
	}

	public function hide_astra_builder_selection_screen(): void {
		add_filter( 'st_enable_block_page_builder', '__return_true' );
	}
}

$hostinger_admin_hooks = new Hostinger_Admin_Hooks();
