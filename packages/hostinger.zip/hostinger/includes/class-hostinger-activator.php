<?php

defined( 'ABSPATH' ) || exit;

class Hostinger_Activator {

	public static function activate(): void {
		require_once HOSTINGER_ABSPATH . 'includes/class-hostinger-default-options.php';
		$options = new Hostinger_Default_Options();
		$options->add_options();

		self::enable_woo_onboarding();
	}

	/**
	 * Enables Woo onboarding flag once plugin is activated
	 *
	 * @return bool
	 */
	public static function enable_woo_onboarding(): bool {
		require_once HOSTINGER_ABSPATH . 'includes/class-hostinger-settings.php';
		require_once HOSTINGER_ABSPATH . 'includes/class-hostinger-helper.php';

		if ( ! Hostinger_Helper::is_woocommerce_site() ) {
			return false;
		}

		$woocommerce_onboarding_profile = get_option('woocommerce_onboarding_profile', null );

		// WooCommerce onboarding already done (skipped).
		if ( ! empty( $woocommerce_onboarding_profile['skipped'] ) ) {
			return false;
		}

		// WooCommerce onboarding already done (completed).
		if ( ! empty( $woocommerce_onboarding_profile['completed'] ) ) {
			return false;
		}

		$woo_onboarding_enabled = get_option( 'hostinger_woo_onboarding_enabled', null );

		if ( $woo_onboarding_enabled == null ) {
			update_option( 'hostinger_woo_onboarding_enabled', true, false );
		}

		return true;
	}
}
