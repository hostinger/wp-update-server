<?php

defined( 'ABSPATH' ) || exit;

class Hostinger_Activator {
	private static $helper;

	public function __construct() {
		self::$helper = new Hostinger_Helper();
	}

	public static function activate(): void {
		require_once HOSTINGER_ABSPATH . 'includes/class-hostinger-default-options.php';
		$options = new Hostinger_Default_Options();
		$options->add_options();
		$activator = new self();

		if ( self::$helper->is_plugin_active( 'astra-sites' ) ) {
			$activator->hide_astra_builder_selection();
		}
	}

	public function hide_astra_builder_selection(): void {
		update_option( 'astra_sites_settings', 'gutenberg' );
		update_option( 'st-elementor-builder-flag', 1 );
	}
}
