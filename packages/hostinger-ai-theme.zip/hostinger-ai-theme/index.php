<?php
/**
 * This file has been left empty on purpose.
 *
 * @package hostinger-ai
 * @since 1.0.0
 */
