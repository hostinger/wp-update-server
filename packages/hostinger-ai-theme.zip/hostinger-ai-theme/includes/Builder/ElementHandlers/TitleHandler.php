<?php

namespace Hostinger\AiTheme\Builder\ElementHandlers;

use DOMElement;

defined( 'ABSPATH' ) || exit;

class TitleHandler implements ElementHandler {
    public function handle(DOMElement &$node, array $element_structure): void
    {
        $node->nodeValue = $element_structure['content'];
    }
}