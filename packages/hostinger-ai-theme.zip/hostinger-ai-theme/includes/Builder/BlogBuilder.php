<?php

namespace Hostinger\AiTheme\Builder;

use Hostinger\AiTheme\Admin\Hooks;
use Hostinger\AiTheme\Constants\PreviewImageConstant;
use Hostinger\AiTheme\Constants\BlogPostConstant;
use Hostinger\WpHelper\Config;
use Hostinger\AiTheme\Requests\Client;
use Hostinger\WpHelper\Utils as Helper;
use stdClass;

defined( 'ABSPATH' ) || exit;

class BlogBuilder {
    /**
     * @var string
     */
    private string $brand_name;
    /**
     * @var string
     */
    private string $website_type;
    /**
     * @var string
     */
    private string $description;

    /**
     * @var Client
     */
    private Client $client;

    /**
     * @var ImageManager
     */
    private ImageManager $image_manager;

    public function __construct( string $brand_name, string $website_type, string $description ) {
        $helper         = new Helper();
        $config_handler = new Config();

        $this->client = new Client( $config_handler->getConfigValue( 'base_rest_uri', HOSTINGER_AI_WEBSITES_REST_URI ), [
            Config::TOKEN_HEADER  => $helper::getApiToken(),
            Config::DOMAIN_HEADER => $helper->getHostInfo(),
            'Content-Type' => 'application/json'
        ] );
        $this->image_manager = new ImageManager();

        $this->brand_name = $brand_name;
        $this->website_type = $website_type;
        $this->description = $description;
    }

    public function generate_blog(): void {
        $blog_posts = array();

        for ($i = 0; $i < 2; $i++) {
            $blog_post = $this->generate_post();

            if (!empty($blog_post)) {
                $blog_posts[] = $blog_post;
            }
        }

        if(empty($blog_posts)) {
            return;
        }

        $created_blog_posts = array();

        foreach($blog_posts as $post) {
            $created_blog_posts[] = $this->create_blog_post( $post );
        }

        update_option( 'hostinger_ai_created_blog_posts', $created_blog_posts );
    }

    /**
     * @return array
     */
    public function get_ai_generated_post_titles(): array {
        return wp_list_pluck( get_posts( [
            'numberposts' => -1,
            'meta_query'  => [
                [
                    'key'     => BlogPostConstant::META_SLUG,
                    'compare' => 'EXISTS',
                ],
            ],
        ] ), 'post_title' );
    }

    public function generate_post(): stdClass {
        $post_type   = 'blog_post';
        $length      = '150-300';
        $voice_tone  = 'neutral';

        $data = [
            'post_type'   => $post_type,
            'tone'        => $voice_tone,
            'length'      => $length,
            'description' => $this->description,
            'used_titles' => $this->get_ai_generated_post_titles(),
        ];

        $response = $this->client->get( ImageManager::GENERATE_CONTENT_ACTION, $data );

        $response_code = wp_remote_retrieve_response_code( $response );

        if ( is_wp_error( $response ) || $response_code !== 200 ) {
            return new StdClass();
        }

        $generated_content = reset( json_decode( $response['body'] )->data );

        if ( isset( $generated_content->tags[0] ) && $generated_content->tags[0] !== '' ) {
            $this->image_manager->set_keyword( $generated_content->tags[0] );
            $image_data = $this->image_manager->get_unsplash_image_data( ! empty( $element_structure['default_content'] ) );

            if ( ! empty( get_object_vars( $image_data ) ) ) {
                $generated_content->image_data = $image_data;
            }
        }

        return $generated_content;
    }

    public function create_blog_post(StdClass $post): int {
        $post_status  = 'publish';
        $content = $post->content;

        $post_data = array(
            'post_title'    => $post->title,
            'post_content'  => $content,
            'post_status'   => $post_status,
            'post_type'     => 'post'
        );

        $post_id = wp_insert_post( $post_data );

        if ( ! empty( get_object_vars( $post->image_data ) ) ) {
            update_post_meta( $post_id, PreviewImageConstant::META_SLUG, $post->image_data->image );

            $this->image_manager->create_blog_image_attachment( $post_id );
        }

        update_post_meta( $post_id, BlogPostConstant::META_SLUG, true );

        return $post_id;
    }
}
