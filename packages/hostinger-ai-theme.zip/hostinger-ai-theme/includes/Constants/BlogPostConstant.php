<?php

namespace Hostinger\AiTheme\Constants;

defined( 'ABSPATH' ) || exit;

class BlogPostConstant {
    public const META_SLUG = 'hostinger_generated_by_ai';
}