<?php

namespace Hostinger\AiTheme;

use Hostinger\WpHelper\Config;

defined( 'ABSPATH' ) || exit;

class Updates {
    /**
     * @var Config
     */
    private Config $config_handler;
    private const DEFAULT_PLUGIN_UPDATE_URI = 'https://hostinger-wp-updates.com?action=get_metadata&slug=hostinger-ai-theme';
    private const CANARY_PLUGIN_UPDATE_URI = 'https://hostinger-canary-wp-updates.com?action=get_metadata&slug=hostinger-ai-theme';

    public function __construct() {
        $this->config_handler = new Config();
        $this->updates();
    }

    /**
     * @return bool
     */
    private function should_use_canary_uri(): bool {
        return isset( $_SERVER['H_PLATFORM'] ) && $_SERVER['H_PLATFORM'] === 'Hostinger' && isset( $_SERVER['H_CANARY'] ) && $_SERVER['H_CANARY'] === true;
    }

    /**
     * @param string $default
     *
     * @return string
     */
    private function get_plugin_update_uri( string $default = self::DEFAULT_PLUGIN_UPDATE_URI ): string {
        if ( $this->should_use_canary_uri() ) {
            return self::CANARY_PLUGIN_UPDATE_URI;
        }

        return $this->config_handler->getConfigValue( 'ai_theme_update_uri', $default );
    }

    /**
     * @return void
     */
    public function updates(): void {
        $plugin_updater_uri = $this->get_plugin_update_uri();

        if ( class_exists( PucFactory::class ) ) {
            $hts_update_checker = PucFactory::buildUpdateChecker(
                $plugin_updater_uri,
                get_template_directory() . DIRECTORY_SEPARATOR . 'functions.php',
                'hostinger-ai-theme'
            );
        }
    }
}