<?php

namespace Hostinger\EasyOnboarding\Admin;

use Hostinger\Surveys\SurveyManager;

class Surveys {
	const CHATBOT_SURVEY_NAME = 'chatbot';
	const CHATBOT_SURVEY_SCORE_QUESTION = 'How would you rate our AI chatbot? (1-10)';
	const CHATBOT_SURVEY_COMMENT_QUESTION = 'How would you rate your experience with the Chatbot? (Comment)';
	const CHATBOT_SURVEY_LOCATION = 'wp-admin';
	const SURVEY_PRIORITY = 999;

	public function init() {
		add_filter( 'hostinger_add_surveys', [ $this, 'createSurveys' ] );
	}

	public function createSurveys( $surveys ) {
		$scoreQuestion   = esc_html__( self::CHATBOT_SURVEY_SCORE_QUESTION, 'hostinger-easy-onboarding' );
		$commentQuestion = esc_html__( self::CHATBOT_SURVEY_COMMENT_QUESTION, 'hostinger-easy-onboarding' );
		$chatbotSurvey   = SurveyManager::addSurvey( self::CHATBOT_SURVEY_NAME, $scoreQuestion, $commentQuestion, self::CHATBOT_SURVEY_LOCATION, self::SURVEY_PRIORITY );
		$surveys[]       = $chatbotSurvey;

		return $surveys;
	}
}
