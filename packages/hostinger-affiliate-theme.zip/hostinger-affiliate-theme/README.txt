=== Hostinger Affiliate Theme ===
Tags: affiliate, hostinger
Requires at least: 5.6
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.8
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Power your affiliate marketing with Hostinges Affiliate WordPress theme. Effortlessly integrate Amazon products, captivate your audience with a responsive design, and customize your site without any coding. Boost performance, track analytics, and turn your passion into profit with ease. Elevate your affiliate game today!

== Changelog ==

1.0.8 (2024-07-10)
- Improved theme updates

1.0.7 (2024-07-09)
- Added readme

1.0.6 (2024-07-05)
- Added translations

1.0.5 (2024-06-18)
- Added es_ES translations

1.0.4 (2024-05-28)
- Fixed theme update url issue

1.0.3 (2024-03-06)
- Css improvements

1.0.2 (2024-02-07)
- Fixes

1.0.1 (2024-01-16)
- Added updates for the theme
- Added gutenberg blocks

