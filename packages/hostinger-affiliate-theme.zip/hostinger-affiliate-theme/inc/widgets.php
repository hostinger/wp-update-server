<?php
/**
 * Widget API Generator
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage Orbital
 * @since 1.0
 */

require get_template_directory() . '/inc/widgets/class-wp-widget-recent-posts.php';
