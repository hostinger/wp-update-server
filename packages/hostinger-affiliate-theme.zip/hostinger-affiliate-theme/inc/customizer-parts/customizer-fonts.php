<?php
function orbital_customizer_fonts()
{

	$fontsObj = array (
        //Fonts
		'items' =>
		array (
			array (
				'family' => 'Roboto',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'500',
					'700',
					'900',
				),
			),
			array (
				'family' => 'Open Sans',
				'variants' =>
				array (
					'300',
					'400',
					'600',
					'700',
					'800',
				),
			),
			array (
				'family' => 'Slabo 27px',
				'variants' =>
				array (
					'400',
				),
			),
			array (
				'family' => 'Lato',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'700',
					'900',
				),
			),
			array (
				'family' => 'Oswald',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),
			array (
				'family' => 'Roboto Condensed',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),
			array (
				'family' => 'Source Sans Pro',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'600',
					'700',
					'900',
				),
			),
			array (
				'family' => 'Montserrat',
				'variants' =>
				array (
					'400',
					'700',
				),
			),
			array (
				'family' => 'Raleway',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),
			array (
				'family' => 'PT Sans',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Roboto Slab',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Merriweather',
				'variants' =>
				array (
					'300',
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Open Sans Condensed',
				'variants' =>
				array (
					'300',
					'700',
				),
			),

			array (
				'family' => 'Droid Sans',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Lora',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Ubuntu',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'700',
				),
			),

			array (
				'family' => 'Droid Serif',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Playfair Display',
				'variants' =>
				array (
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Arimo',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Titillium Web',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'600',
					'700',
					'900',
				),
			),

			array (
				'family' => 'PT Sans Narrow',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Noto Sans',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'PT Serif',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Muli',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Indie Flower',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bitter',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Inconsolata',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Dosis',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Poppins',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Fjalla One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Hind',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Cabin',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Oxygen',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Anton',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Noto Serif',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Arvo',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Lobster',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Catamaran',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Yanone Kaffeesatz',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Crimson Text',
				'variants' =>
				array (
					'400',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Bree Serif',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nunito',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Libre Baskerville',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Josefin Sans',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Abel',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gloria Hallelujah',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Abril Fatface',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Merriweather Sans',
				'variants' =>
				array (
					'300',
					'400',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Fira Sans',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Exo 2',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Varela Round',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Pacifico',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Asap',
				'variants' =>
				array (
					'400',
					'500',
					'700',
				),
			),

			array (
				'family' => 'Ubuntu Condensed',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Amatic SC',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Quicksand',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'700',
				),
			),

			array (
				'family' => 'Roboto Mono',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'500',
					'700',
				),
			),

			array (
				'family' => 'Karla',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Shadows Into Light',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Questrial',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Archivo Narrow',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Signika',
				'variants' =>
				array (
					'300',
					'400',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Rubik',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Cuprum',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Play',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Dancing Script',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Alegreya',
				'variants' =>
				array (
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Work Sans',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Vollkorn',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'PT Sans Caption',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Francois One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Maven Pro',
				'variants' =>
				array (
					'400',
					'500',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Pathway Gothic One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rokkitt',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Orbitron',
				'variants' =>
				array (
					'400',
					'500',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Exo',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Patua One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Acme',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Source Code Pro',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'900',
				),
			),

			array (
				'family' => 'EB Garamond',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ropa Sans',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Architects Daughter',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Alegreya Sans',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'500',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Crete Round',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Russo One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Arapey',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Comfortaa',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Lobster Two',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Josefin Slab',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Monda',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Source Serif Pro',
				'variants' =>
				array (
					'400',
					'600',
					'700',
				),
			),

			array (
				'family' => 'News Cycle',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Cinzel',
				'variants' =>
				array (
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Quattrocento Sans',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'ABeeZee',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Noticia Text',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Hammersmith One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Pontano Sans',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Satisfy',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Righteous',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Yellowtail',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kaushan Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Old Standard TT',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Poiret One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Domine',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Gudea',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Sanchez',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Libre Franklin',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Quattrocento',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Passion One',
				'variants' =>
				array (
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Courgette',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Armata',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'BenchNine',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Teko',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Economica',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Tinos',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Istok Web',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Permanent Marker',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Archivo Black',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kalam',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Cookie',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Playfair Display SC',
				'variants' =>
				array (
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Cardo',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Boogaloo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ruda',
				'variants' =>
				array (
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Alfa Slab One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Oleo Script',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Chewy',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Philosopher',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Kanit',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Handlee',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cabin Condensed',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Great Vibes',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Coming Soon',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cormorant Garamond',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Antic Slab',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Vidaloka',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Tangerine',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Rajdhani',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Audiowide',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Yantramanav',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'500',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Days One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Khand',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Ek Mukta',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Playball',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Droid Sans Mono',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kreon',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Sintony',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Bangers',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Didact Gothic',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bevan',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Neuton',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Shadows Into Light Two',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Voltaire',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fredoka One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Glegoo',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Amiri',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Cantarell',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Amaranth',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Rock Salt',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Shrikhand',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Volkhov',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Rambla',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Sorts Mill Goudy',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Damion',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Marck Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sacramento',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Coda',
				'variants' =>
				array (
					'400',
					'800',
				),
			),

			array (
				'family' => 'Changa One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gentium Book Basic',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Bad Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Actor',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Adamina',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Copse',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Signika Negative',
				'variants' =>
				array (
					'300',
					'400',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Alice',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gochi Hand',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cantata One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Jura',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
				),
			),

			array (
				'family' => 'Varela',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Luckiest Guy',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Julius Sans One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Jaldi',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Paytone One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nobile',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Gentium Basic',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'VT323',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nothing You Could Do',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cousine',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Sigmar One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Covered By Your Grace',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Homemade Apple',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Patrick Hand',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ultra',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Special Elite',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sarala',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Antic',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Scada',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'PT Mono',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Squada One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Hind Vadodara',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Pinyon Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Heebo',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'500',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Alex Brush',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rancho',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Basic',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Homenaje',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Electrolize',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Unica One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kameron',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Calligraffitti',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Molengo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Enriqueta',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Prata',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Neucha',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Hind Siliguri',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Fugaz One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Share',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Carme',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Arbutus Slab',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Contrail One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Martel',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'PT Serif Caption',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Viga',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Reenie Beanie',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cairo',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'600',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Pragati Narrow',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Cherry Cream Soda',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bubblegum Sans',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cabin Sketch',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Alegreya Sans SC',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'500',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Khula',
				'variants' =>
				array (
					'300',
					'400',
					'600',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Just Another Hand',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Syncopate',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Allura',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Caveat',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Alef',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Convergence',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Overlock',
				'variants' =>
				array (
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Niconne',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Marvel',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Ceviche One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Michroma',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ubuntu Mono',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Aldrich',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Press Start 2P',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Share Tech Mono',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Marmelad',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Freckle Face',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nixie One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fauna One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Advent Pro',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Caveat Brush',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Average',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Limelight',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fontdiner Swanky',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Lusitana',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Rochester',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Montserrat Alternates',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Ruslan Display',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Oranienbaum',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Allerta Stencil',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Black Ops One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Halant',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Marcellus',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Frank Ruhl Libre',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Chivo',
				'variants' =>
				array (
					'300',
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Telex',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Spinnaker',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Lustria',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Jockey One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Monoton',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Leckerli One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Quantico',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Cambay',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Fanwood Text',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Tauri',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Marcellus SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Walter Turncoat',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Allerta',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Hanuman',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Goudy Bookletter 1911',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Grand Hotel',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Crafty Girls',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sansita One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Parisienne',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Allan',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Candal',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sue Ellen Francisco',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Coustard',
				'variants' =>
				array (
					'400',
					'900',
				),
			),

			array (
				'family' => 'Carter One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Slabo 13px',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Waiting for the Sunrise',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Carrois Gothic',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Aclonica',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fredericka the Great',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Annie Use Your Telescope',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Concert One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Average Sans',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Radley',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Puritan',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Kelly Slab',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cutive',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Doppio One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cinzel Decorative',
				'variants' =>
				array (
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Rufina',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Italianno',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Schoolbell',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Port Lligat Slab',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Alegreya SC',
				'variants' =>
				array (
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Anonymous Pro',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Merienda',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Metrophobic',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rosario',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Magra',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Six Caps',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Graduate',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Arima Madurai',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Slackey',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Yesteryear',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Prompt',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Racing Sans One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Lateef',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Hind Guntur',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Assistant',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'600',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Eczar',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Lalezar',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Petit Formal Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mr Dafoe',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Caudex',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Forum',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gilda Display',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Inder',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Poly',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Give You Glory',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gruppo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Andika',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Berkshire Swash',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Lilita One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Trocchi',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Montez',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Wire One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'GFS Didot',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Martel Sans',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Tenor Sans',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Love Ya Like A Sister',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Anaheim',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mako',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mate',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Oleo Script Swash Caps',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Oregano',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rammetto One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Strait',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Capriola',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Baloo Paaji',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Quando',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Happy Monkey',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Belleza',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Lekton',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Just Me Again Down Here',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Duru Sans',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Alike',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Euphoria Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Zeyada',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Karma',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Corben',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Unkempt',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Merienda One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Iceland',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kranky',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Delius',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Averia Serif Libre',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Yeseva One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Knewave',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'IM Fell Double Pica',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bentham',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Clicker Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Brawler',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Crushed',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Prosto One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Baumans',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bowlby One SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Chelsea Market',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bungee Inline',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mr De Haviland',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Andada',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Skranji',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Nova Square',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Oxygen Mono',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bowlby One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'The Girl Next Door',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Judson',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Pompiere',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Aladin',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Arizonia',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Revalia',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Wendy One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nunito Sans',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Herr Von Muellerhoff',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Biryani',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'IM Fell English',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ovo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Voces',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sniglet',
				'variants' =>
				array (
					'400',
					'800',
				),
			),

			array (
				'family' => 'Londrina Solid',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Trirong',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'UnifrakturMaguntia',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Lemon',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Imprima',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gravitas One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Short Stack',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Qwigley',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gabriela',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gafata',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Unna',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Orienta',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Holtwood One SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Norican',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Lily Script One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Finger Paint',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Della Respira',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'La Belle Aurore',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ramabhadra',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Carrois Gothic SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'IM Fell DW Pica',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mountains of Christmas',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Shojumaru',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Loved by the King',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Megrim',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Belgrano',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Titan One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Khmer',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Changa',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Reem Kufi',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kurale',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cherry Swash',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Raleway Dots',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kristi',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bilbo Swash Caps',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Chau Philomene One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sofia',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Palanquin',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Artifika',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kotta One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Headland One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Denk One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Stardos Stencil',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Frijole',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Shanti',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cambo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Expletus Sans',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Patrick Hand SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Itim',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Seaweed Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fondamento',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Over the Rainbow',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Timmana',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Londrina Outline',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Simonetta',
				'variants' =>
				array (
					'400',
					'900',
				),
			),

			array (
				'family' => 'Federo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Tienne',
				'variants' =>
				array (
					'400',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Aguafina Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Pattaya',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cutive Mono',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fenix',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Averia Sans Libre',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Rouge Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Stalemate',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Dorsa',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Amethysta',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ledger',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Delius Swash Caps',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Vast Shadow',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Engagement',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mallanna',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Odor Mean Chey',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Abhaya Libre',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Meddon',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Salsa',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Englebert',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Life Savers',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Italiana',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Podkova',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Scheherazade',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Balthazar',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Prociono',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Medula One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Dawning of a New Day',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rationale',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Athiti',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Fira Mono',
				'variants' =>
				array (
					'400',
					'500',
					'700',
				),
			),

			array (
				'family' => 'Cedarville Cursive',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nova Mono',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'IM Fell English SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Chicle',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kadwa',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Delius Unicase',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Mouse Memoirs',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Share Tech',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Geo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'IM Fell French Canon',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Irish Grover',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kite One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Suranna',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sunshiney',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Amarante',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Inika',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Codystar',
				'variants' =>
				array (
					'300',
					'400',
				),
			),

			array (
				'family' => 'Poller One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Metamorphous',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sree Krushnadevaraya',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sail',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mate SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Creepster',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fira Sans Extra Condensed',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'McLaren',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rye',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rosarivo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Dynalight',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Julee',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'IM Fell DW Pica SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Habibi',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Numans',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mystery Quest',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Esteban',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gurajada',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Buenard',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Cantora One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Angkor',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nokora',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Fjord One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Text Me One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Wallpoet',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'David Libre',
				'variants' =>
				array (
					'400',
					'500',
					'700',
				),
			),

			array (
				'family' => 'Condiment',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Maiden Orange',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mitr',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Vampiro One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'NTR',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Flamenco',
				'variants' =>
				array (
					'300',
					'400',
				),
			),

			array (
				'family' => 'Averia Libre',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Quintessential',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Secular One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Taviraj',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Montserrat Subrayada',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'IM Fell Great Primer',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kavoon',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kumar One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Coda Caption',
				'variants' =>
				array (
					'800',
				),
			),

			array (
				'family' => 'Donegal One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Vibur',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Milonga',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Stoke',
				'variants' =>
				array (
					'300',
					'400',
				),
			),

			array (
				'family' => 'Miriam Libre',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Suez One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ruthie',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Vesper Libre',
				'variants' =>
				array (
					'400',
					'500',
					'700',
					'900',
				),
			),

			array (
				'family' => 'Amatica SC',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Rozha One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Paprika',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sumana',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Krona One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sarpanch',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Aref Ruqaa',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Mandali',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Dekko',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Junge',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Buda',
				'variants' =>
				array (
					'300',
				),
			),

			array (
				'family' => 'Baloo Tamma',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mada',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'900',
				),
			),

			array (
				'family' => 'Galindo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Chonburi',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bungee Shade',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ruluko',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Proza Libre',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Palanquin Dark',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Sonsie One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Stint Ultra Condensed',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Tulpen One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Maitree',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'League Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mrs Saint Delafield',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Suwannaphum',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Piedra',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sriracha',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'IM Fell French Canon SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bilbo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Elsie',
				'variants' =>
				array (
					'400',
					'900',
				),
			),

			array (
				'family' => 'Overlock SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sancreek',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Asul',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Alike Angular',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Swanky and Moo Moo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Battambang',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'New Rocker',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Trade Winds',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'IM Fell Double Pica SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cormorant',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Linden Hill',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nova Round',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Miniver',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Almendra',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Stint Ultra Expanded',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Pridi',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Bigshot One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Glass Antiqua',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cagliostro',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Offside',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'IM Fell Great Primer SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Antic Didone',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'GFS Neohellenic',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Nosifer',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ribeye',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Akronim',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Henny Penny',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Jolly Lodger',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Meie Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fira Sans Condensed',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Emilys Candy',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Pirata One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Hind Madurai',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Port Lligat Sans',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Baloo Bhaina',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sarina',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Monsieur La Doulaise',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'El Messiri',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Bungee',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nova Slim',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Autour One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rum Raisin',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Wellfleet',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Iceberg',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bokor',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Trykker',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Jacques Francois',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Croissant One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Redressed',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Arsenal',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Oldenburg',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Lovers Quarrel',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Monofett',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'MedievalSharp',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Peralta',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Joti One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Scope One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Amita',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Moul',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ramaraja',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'UnifrakturCook',
				'variants' =>
				array (
					'700',
				),
			),

			array (
				'family' => 'Laila',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Snippet',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bubbler One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Montaga',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Baloo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Yrsa',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Atomic Age',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Faster One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nova Flat',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Germania One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rubik Mono One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Koulen',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fresca',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Modern Antiqua',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sura',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Miltonian Tattoo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Baloo Chettan',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Spicy Rice',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Margarine',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Eagle Lake',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Amiko',
				'variants' =>
				array (
					'400',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Petrona',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Space Mono',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Original Surfer',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Chango',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Almendra SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Taprom',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Baloo Thambi',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Galdeano',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nova Oval',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Purple Purse',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rhodium Libre',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sahitya',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Arya',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Jomhuria',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Molle',
				'variants' =>
				array (
				),
			),

			array (
				'family' => 'Dr Sugiyama',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ewert',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Snowburst One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cormorant Infant',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Kenia',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Keania One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Trochut',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Lancelot',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Astloch',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Overpass',
				'variants' =>
				array (
					'100',
					'200',
					'300',
					'400',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Lemonada',
				'variants' =>
				array (
					'300',
					'400',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Harmattan',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Smythe',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Griffy',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Caesar Dressing',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Averia Gruesa Libre',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Freehand',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ranchers',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Galada',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Content',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Fascinate',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gorditas',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Metal',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ribeye Marrow',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Passero One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Jacques Francois Shadow',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Felipa',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Pavanam',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Risque',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Elsie Swash Caps',
				'variants' =>
				array (
					'400',
					'900',
				),
			),

			array (
				'family' => 'Romanesco',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Diplomata',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Devonshire',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Tillana',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Mirza',
				'variants' =>
				array (
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'BioRhyme',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Plaster',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Miltonian',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Warnes',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nova Script',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Londrina Shadow',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Underdog',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kdam Thmor',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Marko One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Goblin One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Seymour One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Miss Fajardose',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Siemreap',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Nova Cut',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sofadi One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sansita',
				'variants' =>
				array (
					'400',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Londrina Sketch',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ranga',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Asset',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rakkas',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Macondo Swash Caps',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Spirax',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Princess Sofia',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bayon',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mrs Sheppards',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Geostar Fill',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Atma',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Pangolin',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mukta Vaani',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Modak',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cormorant Upright',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Baloo Bhai',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ravi Prakash',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Geostar',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Aubrey',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sirin Stencil',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Farsan',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Inknut Antiqua',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
					'800',
					'900',
				),
			),

			array (
				'family' => 'Smokum',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cormorant SC',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Butterfly Kids',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Metal Mania',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Yatra One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Combo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bigelow Rules',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Uncial Antiqua',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Preahvihear',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Chenla',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Macondo',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Barrio',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Dangrek',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Arbutus',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Sevillana',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Coiny',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Baloo Da',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Erica One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Federant',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Lakki Reddy',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Supermercado One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Diplomata SC',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Jim Nightshade',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Stalinist One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Almendra Display',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bonbon',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Rasa',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Mr Bedfort',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fascinate Inline',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Flavors',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Eater',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Chela One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Ruge Boogie',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Unlock',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Mogra',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Emblema One',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Butcherman',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Tenali Ramakrishna',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Gidugu',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Chathura',
				'variants' =>
				array (
					'100',
					'300',
					'400',
					'700',
					'800',
				),
			),

			array (
				'family' => 'Fruktur',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Asar',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Fasthand',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Katibeh',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kantumruy',
				'variants' =>
				array (
					'300',
					'400',
					'700',
				),
			),

			array (
				'family' => 'Moulpali',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Cormorant Unicase',
				'variants' =>
				array (
					'300',
					'400',
					'500',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Peddana',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bungee Hairline',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Padauk',
				'variants' =>
				array (
					'400',
					'700',
				),
			),

			array (
				'family' => 'Meera Inimai',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kumar One Outline',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bahiana',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Suravaram',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Overpass Mono',
				'variants' =>
				array (
					'300',
					'400',
					'600',
					'700',
				),
			),

			array (
				'family' => 'Dhurjati',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Hanalei Fill',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Hanalei',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Kavivanar',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'Bungee Outline',
				'variants' =>
				array (
					'400',
				),
			),

			array (
				'family' => 'BioRhyme Expanded',
				'variants' =>
				array (
					'200',
					'300',
					'400',
					'700',
					'800',
				),
			),
		),
);
foreach ($fontsObj['items'] as $font) {
	foreach ($font['variants'] as $variant) {
		$arrayFonts[$font['family'] .':'. $variant] = $font['family'] .' '. $variant;
	}
}
return $arrayFonts;
}
