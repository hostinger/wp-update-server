( function( $ ) {

	var HostingerAftEI = {

		init: function()
		{
			$( 'input[name=hostinger-aft-ei-export-button]' ).on( 'click', HostingerAftEI._export );
			$( 'input[name=hostinger-aft-ei-import-button]' ).on( 'click', HostingerAftEI._import );
		},

		_export: function()
		{
			window.location.href = hostingerafteiConfig.customizerURL + '?hostinger-aft-ei-export=' + hostingerafteiConfig.exportNonce;
		},

		_import: function()
		{
			var win			= $( window ),
				body		= $( 'body' ),
				form		= $( '<form class="hostinger-aft-ei-form" method="POST" enctype="multipart/form-data"></form>' ),
				controls	= $( '.hostinger-aft-ei-import-controls' ),
				file		= $( 'input[name=hostinger-aft-ei-import-file]' ),
				message		= $( '.hostinger-aft-ei-uploading' );

			if ( '' == file.val() ) {
				alert( hostingerafteil10n.emptyImport );
			}
			else {
				win.off( 'beforeunload' );
				body.append( form );
				form.append( controls );
				message.show();
				form.submit();
			}
		}
	};

	$( HostingerAftEI.init );

})( jQuery );