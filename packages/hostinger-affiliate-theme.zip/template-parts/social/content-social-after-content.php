<?php
if (hostinger_aft_check_social_template('hostinger_aft_social_after_content_post_types')) {
	return;
}

$devices = hostinger_aft_customize_option('hostinger_aft_social_after_content_devices') ? hostinger_aft_customize_option('hostinger_aft_social_after_content_devices') : 'all';
$social_networks = explode(',', hostinger_aft_customize_option('hostinger_aft_social_after_content_social'));
?>

<div class="entry-social <?php echo $devices; ?> <?php if (hostinger_aft_customize_option('hostinger_aft_social_after_content_count')) {
	echo 'social-count';
} ?>">
<?php foreach ($social_networks as $social_network) {
	echo '<a href="#" class="social social-'. $social_network .'"></a>';
}
?>
</div>
