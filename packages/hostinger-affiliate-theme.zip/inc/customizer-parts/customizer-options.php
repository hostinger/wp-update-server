<?php

// GOOGLE ANALYTICS
function hostinger_aft_enqueue_analytics() {
    if (hostinger_aft_gdpr_show_cookies('analytics_ads')) {
        if (hostinger_aft_customize_option('hostinger_aft_seo_analytics')) {
            echo hostinger_aft_customize_option('hostinger_aft_seo_analytics');
        }
    }
}

function hostinger_aft_enqueue_adsense() {
    if (hostinger_aft_gdpr_show_cookies('analytics_ads')) {
        if (hostinger_aft_customize_option('hostinger_aft_seo_adsense')) {
            echo hostinger_aft_customize_option('hostinger_aft_seo_adsense');
        }
    }
}

//GOOGLE FONTS SCRIPT
function hostinger_aft_fonts_head() {
    ?>
    <style>
    <?php
    if (hostinger_aft_customize_option('hostinger_aft_typo_headings')) {
        $heading = explode(':', hostinger_aft_customize_option('hostinger_aft_typo_headings'));
        ?>
            h1,h2,h3,h4,h5,h6, .title {
                font-family: '<?php echo $heading[0]; ?>', sans-serif;
                font-weight: <?php echo $heading[1]; ?>;
            }
        <?php
    }
    if (hostinger_aft_customize_option('hostinger_aft_typo_body')) {
        $body = explode(':', hostinger_aft_customize_option('hostinger_aft_typo_body'));
        ?>
            body, .site-header {
                font-family: '<?php echo $body[0]; ?>' , sans-serif;
                font-weight: <?php echo $body[1]; ?>;
            }
        <?php
    }
    if (hostinger_aft_customize_option('hostinger_aft_typo_logo')) {
        $logo = explode(':', hostinger_aft_customize_option('hostinger_aft_typo_logo'));
        ?>
            .site-logo a {
                font-family: '<?php echo $logo[0]; ?>' , sans-serif;
                font-weight: <?php echo $logo[1]; ?>;
            }
        <?php
    }
    ?>
    </style>
    <?php
}

function hostinger_aft_customize_css() {

    $container = hostinger_aft_customize_option('hostinger_aft_layout_container') ? hostinger_aft_customize_option('hostinger_aft_layout_container') : 'inherit';
    $relation = hostinger_aft_customize_option('hostinger_aft_layout_relation') ? hostinger_aft_customize_option('hostinger_aft_layout_relation') : 0;
    $order = hostinger_aft_customize_option('hostinger_aft_layout_sidebar_order') ? hostinger_aft_customize_option('hostinger_aft_layout_sidebar_order') : 0;
    ?>
    <style>
        @media(min-width: 48rem){

            .container {
                width: <?php print $container; ?>rem;
            }

            .entry-content {
                max-width: <?php print 100 - $relation; ?>%;
                flex-basis: <?php print 100 - $relation; ?>%;
            }

            .entry-aside {
                max-width: <?php print $relation; ?>%;
                flex-basis: <?php print $relation; ?>%;
                order: <?php echo $order; ?>;
                -ms-flex-order: <?php echo $order; ?>;

            }

        }


    <?php if (hostinger_aft_customize_option('hostinger_aft_link_color')) : ?>
            a {
                color: <?php echo hostinger_aft_customize_option('hostinger_aft_link_color'); ?>;
            }

        <?php endif; ?>


    <?php if (hostinger_aft_customize_option('hostinger_aft_navbar_background')) : ?>
            .site-header {
                background-color: <?php echo hostinger_aft_customize_option('hostinger_aft_navbar_background'); ?>;
            }

        <?php endif; ?>

    <?php if (hostinger_aft_customize_option('hostinger_aft_navbar_link_color')) : ?>
            .site-header a {
                color: <?php echo get_theme_mod('hostinger_aft_navbar_link_color'); ?>;
            }

            @media(min-width: 1040px){
                .site-navbar .menu-item-has-children:after {
                    border-color: <?php echo get_theme_mod('hostinger_aft_navbar_link_color'); ?>;
                }
            }
    <?php endif; ?>


    </style>

        <?php
    }
    