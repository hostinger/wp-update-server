Theme Name: Hostinger Affiliate theme
Theme URI: https://hostinger.com
Author: Hostinger
Author URI: https://hostinger.com/
Description: Hostinger Affiliate theme
Version: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: hostinger-affiliate-theme
