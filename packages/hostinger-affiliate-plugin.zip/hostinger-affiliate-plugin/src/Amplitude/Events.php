<?php
/**
 * Amplitude Events
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Amplitude;

use Hostinger\AffiliatePlugin\Api\RequestsClient;
use Hostinger\AffiliatePlugin\Setup\Config;
use Hostinger\AffiliatePlugin\Functions;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Amplitude events
 */
class Events {
	/**
	 * Endpoint
	 */
	private const AMPLITUDE_ENDPOINT = '/v3/wordpress/plugin/trigger-event';
	/**
	 * @var Config instance
	 */
	private Config $config;
	/**
	 * @var RequestsClient client
	 */
	private RequestsClient $requests_client;
	/**
	 * @var Functions functions
	 */
	private Functions $functions;

	/**
	 *
	 */
	public function __construct() {
		$this->config          = new Config();
		$this->functions       = new Functions();
		$this->requests_client = new RequestsClient();

		$this->requests_client->set_api_url( $this->config->get_config_value( 'base_rest_uri', HOSTINGER_AFFILIATE_REST_URI ) );

		$default_headers = array(
			Config::TOKEN_HEADER  => $this->functions->get_api_token(),
			Config::DOMAIN_HEADER => $this->functions->get_host_info(),
		);

		$this->requests_client->set_default_headers( $default_headers );
	}

	/**
	 * @return void
	 */
	public function init() {
		add_action( 'transition_post_status', array( $this, 'track_published_post' ), 10, 3 );
	}

	/**
	 * @param string $endpoint endpoint to query.
	 * @param array  $params array.
	 *
	 * @return void
	 */
	private function send_request( string $endpoint, array $params ): void {
		// Don't send if we don't have API token.
		if ( empty( $this->functions->get_api_token() ) ) {
			return;
		}

		$response = $this->requests_client->post( $endpoint, array( 'params' => $params ) );

		if ( is_wp_error( $response ) ) {
			error_log( $response );
		}
	}

	/**
	 * @param string $layout display layout.
	 *
	 * @return void
	 */
	public function affiliate_created( $layout ) {
		$endpoint = self::AMPLITUDE_ENDPOINT;

		$params = array(
			'action'      => Actions::AFFILIATE_CREATE,
			'layout_type' => $layout,
		);

		$this->send_request( $endpoint, $params );
	}

	/**
	 * @param string $post_type post type.
	 * @param int    $post_id post id.
	 *
	 * @return void
	 */
	public function affiliate_content_published( string $post_type, int $post_id ): void {
		$endpoint = self::AMPLITUDE_ENDPOINT;
		$params   = array(
			'action' => Actions::AFFILIATE_PUBLISHED,
		);

		$this->send_request( $endpoint, $params );
	}

	/**
	 * @param string   $new_status new post status.
	 * @param string   $old_status old post status.
	 * @param \WP_Post $post post object.
	 *
	 * @return void
	 */
	public function track_published_post( string $new_status, string $old_status, \WP_Post $post ): void {
		$post_id                   = $post->ID;
		static $is_action_executed = array();

		if ( isset( $is_action_executed[ $post_id ] ) ) {
			return;
		}

		if ( ( 'draft' === $old_status || 'auto-draft' === $old_status ) && $new_status === 'publish' ) {
			if ( has_block( 'hostinger-affiliate-plugin/block', $post ) && ! wp_is_post_revision( $post_id ) ) {
				$post_type = get_post_type( $post_id );
				$this->affiliate_content_published( $post_type, $post_id );
				$is_action_executed[ $post_id ] = true;
			}
		}
	}
}
