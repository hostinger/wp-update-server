<?php
namespace Hostinger\AffiliatePlugin\Models\ProductData;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

interface ProductDataParserStrategy {
    public function parse( array $data ): array;
}
