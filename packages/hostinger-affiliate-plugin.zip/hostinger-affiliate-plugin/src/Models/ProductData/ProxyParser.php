<?php
namespace Hostinger\AffiliatePlugin\Models\ProductData;

use Hostinger\AffiliatePlugin\Admin\PluginSettings;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

class ProxyParser implements ProductDataParserStrategy {
    private PluginSettings $plugin_settings;

    public function __construct( PluginSettings $plugin_settings ) {
        $this->plugin_settings = $plugin_settings;
    }
    public function parse( array $data ): array {
        $formatted_data = array();

        $asin = $data['asin'] ?? '';

        if ( empty( $asin ) && ! empty( $data['product_information']['asin'] ) ) {
            $data['asin'] = $data['product_information']['asin'];
        }

        if ( empty( $data['image'] ) && ! empty( $data['images'] ) ) {
            $data['image'] = $data['images'][0];
        }

        if ( ! empty( $data['image'] ) ) {
            $thumbnail = str_replace( '.jpg', '._SL75_.jpg', $data['image'] ) ?? '';
        }

        if ( ! empty( $data['feature_bullets'] ) ) {
            $formatted_data['features'] = $data['feature_bullets'];
        }

        $price    = $data['price'] ?? '';
        $currency = $data['price_symbol'] ?? '';

        if ( empty( $price ) && ! empty( $data['pricing'] ) ) {
            if ( preg_match( '/([\d,.]+)\s*([^\d\s]+)/u', $data['pricing'], $matches ) ) {
                $price    = (float) str_replace( ',', '.', $matches[1] );
                $currency = trim( $matches[2] );
            }
        }

        $rating = $data['stars'] ?? 0;

        if ( empty( $price ) && ! empty( $data['average_rating'] ) ) {
            $rating = $data['average_rating'];
        }

        $plugin_settings = $this->plugin_settings->get_plugin_settings();
        $url             = 'https://www.'
                           . $plugin_settings->amazon->get_domain()
                           . '/dp/'
                           . $asin
                           . '?tag='
                           . $plugin_settings->amazon->get_tracking_id();

        return array(
            'asin'             => $data['asin'] ?? '',
            'title'            => $data['name'] ?? '',
            'url'              => $url,
            'image_url'        => $data['image'] ?? '',
            'thumbnail'        => $thumbnail ?? '',
            'currency'         => $currency,
            'price'            => $price,
            'is_prime'         => $data['has_prime'] ?? false,
            'rating'           => $rating,
            'reviews'          => $data['total_reviews'] ?? 0,
            'is_free_shipping' => false,
            'item_data'        => $formatted_data,
        );
    }
}
