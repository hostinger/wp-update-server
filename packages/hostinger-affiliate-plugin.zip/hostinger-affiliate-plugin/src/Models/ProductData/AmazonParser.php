<?php

namespace Hostinger\AffiliatePlugin\Models\ProductData;

use Hostinger\AffiliatePlugin\Admin\PluginSettings;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

class AmazonParser implements ProductDataParserStrategy {
    private PluginSettings $plugin_settings;
    public function __construct( PluginSettings $plugin_settings ) {
        $this->plugin_settings = $plugin_settings;
    }
    public function parse( array $data ): array {
        $formatted_data = array();

        $by_line_info = array();

        if ( ! empty( $data['ItemInfo']['ByLineInfo']['Brand']['DisplayValue'] ) ) {
            $by_line_info['brand'] = $data['ItemInfo']['ByLineInfo']['Brand']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['ByLineInfo']['Manufacturer']['DisplayValue'] ) ) {
            $by_line_info['manufacturer'] = $data['ItemInfo']['ByLineInfo']['Manufacturer']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['ByLineInfo']['Contributors'] ) ) {
            $contributors = array();

            foreach ( $data['ItemInfo']['ByLineInfo']['Contributors'] as $contributor ) {
                $contributors[] = array(
                    'name'     => ( ! empty( $contributor['Name'] ) ) ? $contributor['Name'] : '',
                    'role'     => ( ! empty( $contributor['Role'] ) ) ? $contributor['Role'] : '',
                    'roleType' => ( ! empty( $contributor['RoleType'] ) ) ? $contributor['RoleType'] : '',
                );
            }

            $by_line_info['contributors'] = $contributors;
        }

        if ( ! empty( $by_line_info ) ) {
            $formatted_data['by_line_info'] = $by_line_info;
        }

        if ( ! empty( $data['ItemInfo']['ContentRating']['AudienceRating']['DisplayValue'] ) ) {
            $formatted_data['audience_rating'] = $data['ItemInfo']['ContentRating']['AudienceRating']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['Classifications']['Binding']['DisplayValue'] ) ) {
            $formatted_data['binding'] = $data['ItemInfo']['Classifications']['Binding']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['Classifications']['ProductGroup']['DisplayValue'] ) ) {
            $formatted_data['product_group'] = $data['ItemInfo']['Classifications']['ProductGroup']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['Features']['DisplayValues'] ) ) {
            $features = array();

            foreach ( $data['ItemInfo']['Features']['DisplayValues'] as $feature ) {
                $features[] = $feature;
            }

            $formatted_data['features'] = $features;
        }

        if ( ! empty( $data['ItemInfo']['ContentInfo']['Edition']['DisplayValue'] ) ) {
            $formatted_data['edition'] = $data['ItemInfo']['ContentInfo']['Edition']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['ContentInfo']['Languages']['DisplayValues'] ) ) {
            $languages = array();

            foreach ( $data['ItemInfo']['ContentInfo']['Languages']['DisplayValues'] as $language ) {
                $languages[] = array(
                    'value' => ( ! empty( $language['DisplayValue'] ) ) ? $language['DisplayValue'] : '',
                    'type'  => ( ! empty( $language['Type'] ) ) ? $language['Type'] : '',
                );
            }

            $formatted_data['languages'] = $languages;
        }

        if ( ! empty( $data['ItemInfo']['ContentInfo']['PagesCount']['DisplayValue'] ) ) {
            $formatted_data['pages_count'] = $data['ItemInfo']['ContentInfo']['PagesCount']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['ContentInfo']['PublicationDate']['DisplayValue'] ) ) {
            $formatted_data['publication_date'] = $data['ItemInfo']['ContentInfo']['PublicationDate']['DisplayValue'];
        }

        $manufacture_info = array();

        if ( ! empty( $data['ItemInfo']['ManufactureInfo']['ItemPartNumber']['DisplayValue'] ) ) {
            $manufacture_info['item_part_number'] = $data['ItemInfo']['ManufactureInfo']['ItemPartNumber']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['ManufactureInfo']['Model']['DisplayValue'] ) ) {
            $manufacture_info['model'] = $data['ItemInfo']['ManufactureInfo']['Model']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['ManufactureInfo']['Warranty']['DisplayValue'] ) ) {
            $manufacture_info['warranty'] = $data['ItemInfo']['ManufactureInfo']['Warranty']['DisplayValue'];
        }

        if ( ! empty( $manufacture_info ) ) {
            $formatted_data['manufacture_info'] = $manufacture_info;
        }

        $product_info = array();

        if ( ! empty( $data['ItemInfo']['ProductInfo']['Color']['DisplayValue'] ) ) {
            $product_info['color'] = $data['ItemInfo']['ProductInfo']['Color']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['ProductInfo']['IsAdultProduct']['DisplayValue'] ) ) {
            $product_info['is_adult_product'] = $data['ItemInfo']['ProductInfo']['IsAdultProduct']['DisplayValue'];
        }

        $item_dimensions = array();

        $possible_item_dimension_keys = array(
            'Height',
            'Length',
            'Weight',
            'Width',
        );

        foreach ( $possible_item_dimension_keys as $key ) {
            if ( ! empty( $data['ItemInfo']['ProductInfo']['ItemDimensions'][ $key ]['DisplayValue'] ) ) {
                $item_dimensions[ strtolower( $key ) ] = $data['ItemInfo']['ProductInfo']['ItemDimensions'][ $key ]['DisplayValue'];
            }
        }

        if ( ! empty( $item_dimensions ) ) {
            $product_info['item_dimensions'] = $item_dimensions;
        }

        if ( ! empty( $data['ItemInfo']['ProductInfo']['ReleaseDate']['DisplayValue'] ) ) {
            $product_info['release_date'] = $data['ItemInfo']['ProductInfo']['ReleaseDate']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['ProductInfo']['Size']['DisplayValue'] ) ) {
            $product_info['size'] = $data['ItemInfo']['ProductInfo']['Size']['DisplayValue'];
        }

        if ( ! empty( $data['ItemInfo']['ProductInfo']['UnitCount']['DisplayValue'] ) ) {
            $product_info['unit_count'] = $data['ItemInfo']['ProductInfo']['UnitCount']['DisplayValue'];
        }

        if ( ! empty( $product_info ) ) {
            $formatted_data['product_info'] = $product_info;
        }

        $technical_info = array();

        if ( ! empty( $data['ItemInfo']['TechnicalInfo']['Formats']['DisplayValues'] ) ) {
            $formats = array();

            foreach ( $data['ItemInfo']['TechnicalInfo']['Formats']['DisplayValues'] as $format ) {
                $formats[] = $format;
            }

            $technical_info['formats'] = $formats;
        }

        if ( ! empty( $data['ItemInfo']['ProductInfo']['EnergyEfficiencyClass']['DisplayValue'] ) ) {
            $technical_info['energy_efficiency_class'] = $data['ItemInfo']['ProductInfo']['EnergyEfficiencyClass']['DisplayValue'];
        }

        if ( ! empty( $technical_info ) ) {
            $formatted_data['technical_info'] = $technical_info;
        }

        return array(
            'asin'             => $data['ASIN'] ?? '',
            'title'            => $data['ItemInfo']['Title']['DisplayValue'] ?? '',
            'url'              => $data['DetailPageURL'] ?? '',
            'image_url'        => $data['Images']['Primary']['Large']['URL'] ?? '',
            'thumbnail'        => $data['Images']['Primary']['Small']['URL'] ?? '',
            'currency'         => $data['Offers']['Listings'][0]['Price']['Currency'] ?? '',
            'price'            => $data['Offers']['Listings'][0]['Price']['Amount'] ?? '',
            'is_prime'         => $data['Offers']['Listings'][0]['DeliveryInfo']['IsPrimeEligible'] ?? false,
            'is_free_shipping' => $data['Offers']['Listings'][0]['DeliveryInfo']['IsFreeShippingEligible'] ?? false,
            'item_data'        => $formatted_data,
        );
    }
}
