<?php
namespace Hostinger\AffiliatePlugin\Models\ProductData;

use Hostinger\AffiliatePlugin\Containers\Container;

class ParserFactory {
    protected Container $container;

    public function __construct( Container $container ) {
        $this->container = $container;
    }

    public function get_parser_strategy( bool $use_amazon_api ): ProductDataParserStrategy {
        if ( $use_amazon_api ) {
            return $this->container->get( AmazonParser::class );
        }

        return $this->container->get( ProxyParser::class );
    }
}
