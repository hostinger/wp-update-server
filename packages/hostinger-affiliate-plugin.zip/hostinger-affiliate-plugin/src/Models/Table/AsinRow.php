<?php
/**
 * Asin Row class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Models\Table;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Asin Row class
 */
class AsinRow {
	/**
	 * @var int
	 */
	private int $index = 0;

	/**
	 * @var string
	 */
	private string $asin = '';

	/**
	 * @var string
	 */
	private string $text_label = '';

	/**
	 * @var string
	 */
	private string $color = '';

	/**
	 * @var bool
	 */
	private bool $is_enabled = false;

	/**
	 * @param int    $index
	 * @param string $asin
	 * @param string $text_label
	 * @param string $color
	 * @param bool   $is_enabled
	 */
	public function __construct( int $index, string $asin, string $text_label, string $color, bool $is_enabled )
	{
		$this->index = $index;
		$this->asin = $asin;
		$this->text_label = $text_label;
		$this->color = $color;
		$this->is_enabled = $is_enabled;
	}

	/**
	 * @return int
	 */
	public function get_index(): int {
		return $this->index;
	}

	/**
	 * @param int $index
	 *
	 * @return void
	 */
	public function set_index( int $index ): void {
		$this->index = $index;
	}

	/**
	 * @return string
	 */
	public function get_asin(): string {
		return $this->asin;
	}

	/**
	 * @param string $asin
	 *
	 * @return void
	 */
	public function set_asin( string $asin ): void {
		$this->asin = $asin;
	}

	/**
	 * @return string
	 */
	public function get_text_label(): string {
		return $this->text_label;
	}

	/**
	 * @param string $text_label
	 *
	 * @return void
	 */
	public function set_text_label( string $text_label ): void {
		$this->text_label = $text_label;
	}

	/**
	 * @return string
	 */
	public function get_color(): string {
		return $this->color;
	}

	/**
	 * @param string $color
	 *
	 * @return void
	 */
	public function set_color( string $color ): void {
		$this->color = $color;
	}

	/**
	 * @return bool
	 */
	public function get_is_enabled(): bool {
		return $this->is_enabled;
	}

	/**
	 * @param bool $is_enabled
	 *
	 * @return void
	 */
	public function set_is_enabled( bool $is_enabled ): void {
		$this->is_enabled = $is_enabled;
	}

	/**
	 * @return array
	 */
	public function to_array(): array {
		return array(
			'index'      => $this->get_index(),
			'asin'       => $this->get_asin(),
			'text_label' => $this->get_text_label(),
			'color'      => $this->get_color(),
			'is_enabled' => $this->get_is_enabled(),
		);
	}
}