<?php

namespace Hostinger\AffiliatePlugin\Api;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

interface AmazonFetchStrategy {
    public function search_items( string $keywords ): mixed;
    public function get_items( array $item_ids ): mixed;
}
