<?php
/**
 * Amazon Client
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Api;

use Hostinger\AffiliatePlugin\Admin\Options\AmazonOptions;
use Hostinger\AffiliatePlugin\Admin\PluginSettings;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Client for doing class to Amazon API
 */
class AmazonClient {
	/**
	 * @var string
	 */
	private $access_key = null;

	/**
	 * @var string
	 */
	private $secret_key = null;

	/**
	 * @var null
	 */
	private $path = null;

	/**
	 * @var string
	 */
	private $region_name = null;

	/**
	 * @var string
	 */
	private $service_name = 'ProductAdvertisingAPI';

	/**
	 * @var null
	 */
	private $request_method = null;

	/**
	 * @var mixed|string
	 */
	private $host = null;

	/**
	 * @var string[]
	 */
	private $aws_headers = array(
		'content-encoding' => 'amz-1.0',
		'content-type'     => 'application/json; charset=utf-8',
	);

	/**
	 * @var array
	 */
	private $payload = array();

	/**
	 * @var null
	 */
	private $partner_tag = null;

	/**
	 * @var string[]
	 */
	private $resources = array(
		'Images.Primary.Large',
		'ItemInfo.ByLineInfo',
		'ItemInfo.ContentInfo',
		'ItemInfo.ContentRating',
		'ItemInfo.Classifications',
		'ItemInfo.Features',
		'ItemInfo.ManufactureInfo',
		'ItemInfo.ProductInfo',
		'ItemInfo.TechnicalInfo',
		'ItemInfo.Title',
		'Offers.Listings.Price',
		'Offers.Listings.DeliveryInfo.IsFreeShippingEligible',
		'Offers.Listings.DeliveryInfo.IsPrimeEligible',
	);

	/**
	 * @var array
	 */
	private $item_ids = array();

	/**
	 * @var array
	 */
	private $keywords = array();

	/**
	 * @var null
	 */
	private $method = null;

	/**
	 * @var string
	 */
	private $hmac_algorithm = 'AWS4-HMAC-SHA256';

	/**
	 * @var string
	 */
	private $aws_request = 'aws4_request';

	/**
	 * @var null
	 */
	private $str_signed_header = null;

	/**
	 * @var string
	 */
	private string $x_amz_date = '';

	/**
	 * @var string
	 */
	private string $current_date = '';

	/**
	 * @var int cache duration in seconds
	 */
	private int $cache_duration = ( 6 * 50 );

	/**
	 * @var RequestsClient requests client
	 */
	private RequestsClient $requests_client;

	/**
	 * @var PluginSettings
	 */
	private PluginSettings $plugin_settings;

	/**
	 * @var AmazonOptions
	 */
	private AmazonOptions $amazon_options;

	/**
	 * @param PluginSettings $plugin_settings Plugin settings.
	 * @param RequestsClient $requests_client Requests client.
	 */
	public function __construct( PluginSettings $plugin_settings, RequestsClient $requests_client ) {

		$this->plugin_settings = $plugin_settings;

		$this->amazon_options = $plugin_settings->get_plugin_settings()->amazon;

		$this->access_key = $this->amazon_options->get_api_key();

		$this->secret_key = $this->amazon_options->get_api_secret();

		$this->region_name = $this->amazon_options->get_region_name();

		$this->host = $this->amazon_options->get_host();

		$this->partner_tag = $this->amazon_options->get_tracking_id();

		$this->x_amz_date = $this->get_time_stamp();

		$this->current_date = $this->get_date();

		$this->requests_client = $requests_client;
	}

	/**
	 * @param String $method Api method.
	 *
	 * @return void
	 */
	public function set_method( $method ) {
		$this->method = $method;

		$this->path = '/paapi5/' . strtolower( $method );
	}

	/**
	 * @param string $request_method Request method.
	 *
	 * @return void
	 */
	public function set_request_method( $request_method ) {
		$this->request_method = $request_method;
	}

	/**
	 * @param array $resources Array of amazon resource object names.
	 *
	 * @return void
	 */
	public function set_resources( array $resources ) {
		$this->resources = array_merge( $this->resources, $resources );
	}

	/**
	 * @param array $item_ids Array of item IDs.
	 *
	 * @return void
	 */
	public function set_item_ids( array $item_ids ): void {
		$this->item_ids = $item_ids;
	}

	/**
	 * @param string $keywords Searchable keywords.
	 *
	 * @return void
	 */
	public function set_keywords( $keywords ) {
		$this->keywords = $keywords;
	}

	/**
	 * @return AmazonOptions
	 */
	public function get_amazon_options() {
		return $this->amazon_options;
	}

	/**
	 * @param string $header_name  Header name.
	 * @param string $header_value Header value.
	 *
	 * @return void
	 */
	public function add_header( $header_name, $header_value ) {
		$this->aws_headers[ $header_name ] = $header_value;
	}

	/**
	 * @return string
	 */
	private function prepare_canonical_request() {
		$canonical_url = '';

		$canonical_url .= $this->request_method . "\n";

		$canonical_url .= $this->path . "\n" . "\n";

		$signed_headers = '';

		foreach ( $this->aws_headers as $key => $value ) {
			$signed_headers .= $key . ';';

			$canonical_url .= $key . ':' . $value . "\n";
		}

		$canonical_url .= "\n";

		$this->str_signed_header = substr( $signed_headers, 0, - 1 );

		$canonical_url .= $this->str_signed_header . "\n";

		$canonical_url .= $this->generate_hex( json_encode( $this->get_payload() ) );

		return $canonical_url;
	}

	/**
	 * @param string $canonical_url URL to sign.
	 *
	 * @return string
	 */
	private function prepare_string_to_sign( $canonical_url ): string {
		$string_to_sign = '';

		$string_to_sign .= $this->hmac_algorithm . "\n";
		$string_to_sign .= $this->x_amz_date . "\n";
		$string_to_sign .= $this->current_date . '/' . $this->region_name . '/' . $this->service_name . '/' . $this->aws_request . "\n";
		$string_to_sign .= $this->generate_hex( $canonical_url );

		return $string_to_sign;
	}

	/**
	 * @param string $string_to_sign String to sign.
	 *
	 * @return string
	 */
	private function calculate_signature( $string_to_sign ): string {
		$signature_key = $this->get_signature_key( $this->secret_key, $this->current_date, $this->region_name, $this->service_name );

		$signature = hash_hmac( 'sha256', $string_to_sign, $signature_key, true );

		return strtolower( bin2hex( $signature ) );
	}

	/**
	 * @return array
	 */
	public function get_payload(): array {
		if ( ! empty( $this->item_ids ) ) {
			$this->payload['ItemIds'] = $this->item_ids;
		}

		if ( ! empty( $this->keywords ) ) {
			$this->payload['Keywords'] = $this->keywords;
		}

		$this->payload['Resources'] = $this->resources;

		$this->payload['PartnerTag'] = $this->partner_tag;

		$this->payload['PartnerType'] = 'Associates';

		$this->payload['Operation'] = $this->method;

		return $this->payload;
	}

	/**
	 * @return string[]
	 */
	public function get_headers(): array {
		$this->add_header( 'host', $this->host );
		$this->add_header( 'x-amz-target', 'com.amazon.paapi5.v1.ProductAdvertisingAPIv1.' . $this->method );
		$this->add_header( 'x-amz-date', $this->x_amz_date );

		ksort( $this->aws_headers );

		// Create a canonical request.
		$canonical_url = $this->prepare_canonical_request();

		// Create the string to sign.
		$string_to_sign = $this->prepare_string_to_sign( $canonical_url );

		// Calculate signature.
		$signature = $this->calculate_signature( $string_to_sign );

		// Calculate authorization header.
		if ( ! empty( $signature ) ) {
			$this->aws_headers['Authorization'] = $this->build_authorization_string( $signature );
		}

		return $this->aws_headers;
	}

	/**
	 * @param string $str_signature Signature.
	 *
	 * @return string
	 */
	private function build_authorization_string( $str_signature ): string {
		return $this->hmac_algorithm . ' ' . 'Credential=' . $this->access_key . '/' . $this->get_date() . '/' . $this->region_name . '/' . $this->service_name . '/' . $this->aws_request . ',' . 'SignedHeaders=' . $this->str_signed_header . ',' . 'Signature=' . $str_signature;
	}

	/**
	 * @param string $data Data from which hex will be generated.
	 *
	 * @return string
	 */
	private function generate_hex( $data ): string {
		return strtolower( bin2hex( hash( 'sha256', $data, true ) ) );
	}

	/**
	 * @param string $key          Key.
	 * @param string $date         Date.
	 * @param string $region_name  Amazon region name.
	 * @param string $service_name Amazon service name.
	 *
	 * @return string
	 */
	private function get_signature_key( $key, $date, $region_name, $service_name ): string {
		$k_secret = 'AWS4' . $key;

		$k_date = hash_hmac( 'sha256', $date, $k_secret, true );

		$k_region = hash_hmac( 'sha256', $region_name, $k_date, true );

		$k_service = hash_hmac( 'sha256', $service_name, $k_region, true );

		$k_signing = hash_hmac( 'sha256', $this->aws_request, $k_service, true );

		return $k_signing;
	}

	/**
	 * @return string
	 */
	private function get_time_stamp(): string {
		return gmdate( 'Ymd\THis\Z' );
	}

	/**
	 * @return string
	 */
	private function get_date(): string {
		return gmdate( 'Ymd' );
	}

	/**
	 * @return array[]|false|mixed
	 */
	public function make_http_request(): mixed {
		$cache_key = $this->generate_cache_key();

		$cached_data = $this->get_cache( $cache_key );

		if ( ! empty( $cached_data ) ) {
			return $cached_data;
		}

		$this->requests_client->set_api_url( 'https://' . $this->host );

		$response = $this->requests_client->post( $this->path, json_encode( $this->get_payload() ), $this->get_headers() );

		if ( is_wp_error( $response ) ) {
			return array(
				'Errors' => array(
					array(
						'Code'    => 'RequestFail',
						'Message' => $response->get_error_message(),
					),
				),
			);
		}

		if ( empty( $response['body'] ) ) {
			return array();
		}

		$body = json_decode( $response['body'], true );

		if ( empty( $body ) ) {
			return array();
		}

		$this->set_cache( $cache_key, $body );

		return $body;
	}

	/**
	 * @param string $keywords keywords you wanna search for.
	 *
	 * @return array[]|false|mixed
	 */
	public function search_items( string $keywords ): mixed {
		$this->set_method( 'SearchItems' );
		$this->set_request_method( 'POST' );
		$this->set_keywords( $keywords );

		return $this->make_http_request();
	}

	/**
	 * @param array $item_ids asins.
	 *
	 * @return array[]|false|mixed
	 */
	public function get_items( array $item_ids ) {
		$this->set_method( 'GetItems' );
		$this->set_request_method( 'POST' );
		$this->set_item_ids( $item_ids );

		return $this->make_http_request();
	}

	/**
	 * @return string
	 */
	private function generate_cache_key(): string {
		return 'amazon_api_' . md5( json_encode( $this->get_payload() ) );
	}

	/**
	 * @param string $cache_key cache key.
	 *
	 * @return mixed
	 */
	private function get_cache( string $cache_key ): mixed {
		return get_transient( $cache_key );

		return false;
	}

	/**
	 * @param string $cache_key cache key.
	 * @param mixed  $data      cache data.
	 *
	 * @return bool
	 */
	private function set_cache( string $cache_key, mixed $data ): bool {
		return set_transient( $cache_key, $data, $this->cache_duration );
	}
}