<?php
namespace Hostinger\AffiliatePlugin\Api;

use Hostinger\AffiliatePlugin\Admin\Options\AmazonOptions;
use Hostinger\AffiliatePlugin\Admin\PluginSettings;
use Hostinger\AffiliatePlugin\Errors\AmazonApiError;
use Hostinger\AffiliatePlugin\Models\Product;
use Hostinger\AffiliatePlugin\Models\ProductData\ParserFactory;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

class AmazonClient implements AmazonFetchStrategy {
    private string $access_key     = '';
    private string $secret_key     = '';
    private string $path           = '';
    private string $region_name    = '';
    private string $service_name   = 'ProductAdvertisingAPI';
    private string $request_method = '';
    private string $host           = '';
    private array $aws_headers     = array(
        'content-encoding' => 'amz-1.0',
        'content-type'     => 'application/json; charset=utf-8',
    );
    private array $payload         = array();
    private string $partner_tag    = '';
    private array $resources       = array(
        'Images.Primary.Small',
        'Images.Primary.Large',
        'ItemInfo.ByLineInfo',
        'ItemInfo.ContentInfo',
        'ItemInfo.ContentRating',
        'ItemInfo.Classifications',
        'ItemInfo.Features',
        'ItemInfo.ManufactureInfo',
        'ItemInfo.ProductInfo',
        'ItemInfo.TechnicalInfo',
        'ItemInfo.Title',
        'Offers.Listings.Price',
        'Offers.Listings.DeliveryInfo.IsFreeShippingEligible',
        'Offers.Listings.DeliveryInfo.IsPrimeEligible',
    );

    private array $item_ids           = array();
    private string $keywords          = '';
    private string $method            = '';
    private string $hmac_algorithm    = 'AWS4-HMAC-SHA256';
    private string $aws_request       = 'aws4_request';
    private string $str_signed_header = '';
    private string $x_amz_date        = '';
    private string $current_date      = '';
    private int $cache_duration       = ( 6 * 50 );
    private RequestsClient $requests_client;
    private PluginSettings $plugin_settings;
    private AmazonOptions $amazon_options;
    private ParserFactory $parser_factory;

    public function __construct( PluginSettings $plugin_settings, RequestsClient $requests_client, ParserFactory $parser_factory ) {
        $this->plugin_settings = $plugin_settings;
        $this->x_amz_date      = $this->get_time_stamp();
        $this->current_date    = $this->get_date();
        $this->requests_client = $requests_client;
        $this->parser_factory  = $parser_factory;

        $this->set_keys();
    }

    public function set_method( string $method ): void {
        $this->method = $method;

        $this->path = '/paapi5/' . strtolower( $method );
    }

    public function set_request_method( string $request_method ): void {
        $this->request_method = $request_method;
    }

    public function set_resources( array $resources ): void {
        $this->resources = array_merge( $this->resources, $resources );
    }

    public function set_item_ids( array $item_ids ): void {
        $this->item_ids = $item_ids;
    }

    public function set_keywords( string $keywords ): void {
        $this->keywords = $keywords;
    }

    public function get_amazon_options(): AmazonOptions {
        return $this->amazon_options;
    }

    public function add_header( string $header_name, string $header_value ): void {
        $this->aws_headers[ $header_name ] = $header_value;
    }

    public function get_payload(): array {
        if ( ! empty( $this->item_ids ) ) {
            $this->payload['ItemIds'] = $this->item_ids;
        }

        if ( ! empty( $this->keywords ) ) {
            $this->payload['Keywords'] = $this->keywords;
        }

        $this->payload['Resources'] = $this->resources;

        $this->payload['PartnerTag'] = $this->partner_tag;

        $this->payload['PartnerType'] = 'Associates';

        $this->payload['Operation'] = $this->method;

        return $this->payload;
    }

    public function get_headers(): array {
        $this->add_header( 'host', $this->host );
        $this->add_header( 'x-amz-target', 'com.amazon.paapi5.v1.ProductAdvertisingAPIv1.' . $this->method );
        $this->add_header( 'x-amz-date', $this->x_amz_date );

        ksort( $this->aws_headers );

        // Create a canonical request.
        $canonical_url = $this->prepare_canonical_request();

        // Create the string to sign.
        $string_to_sign = $this->prepare_string_to_sign( $canonical_url );

        // Calculate signature.
        $signature = $this->calculate_signature( $string_to_sign );

        // Calculate authorization header.
        if ( ! empty( $signature ) ) {
            $this->aws_headers['Authorization'] = $this->build_authorization_string( $signature );
        }

        return $this->aws_headers;
    }

    public function make_http_request(): mixed {
        $cache_key = $this->generate_cache_key();

        $cached_data = $this->get_cache( $cache_key );

        if ( ! empty( $cached_data ) ) {
            return $cached_data;
        }

        $this->requests_client->set_api_url( 'https://' . $this->host );

        $response = $this->requests_client->post( $this->path, json_encode( $this->get_payload() ), $this->get_headers() );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        if ( empty( $response['body'] ) ) {
            return array();
        }

        $body = json_decode( $response['body'], true );

        if ( empty( $body ) ) {
            return array();
        }

        if ( ! empty( $body['Errors'] ) ) {
            return new AmazonApiError( $body['Errors'] );
        }

        $this->set_cache( $cache_key, $body );

        return $body;
    }

    public function search_items( string $keywords ): mixed {
        $this->set_method( 'SearchItems' );
        $this->set_request_method( 'POST' );
        $this->set_keywords( $keywords );

        $response = $this->make_http_request();

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        if ( empty( $response['SearchResult']['Items'] ) ) {
            return array();
        }

        $items = $response['SearchResult']['Items'];

        return $this->parse_items( $items );
    }

    public function set_plugin_settings( PluginSettings $plugin_settings ): void {
        $this->plugin_settings = $plugin_settings;

        $this->set_keys();
    }

    public function get_items( array $item_ids ): mixed {
        $this->set_method( 'GetItems' );
        $this->set_request_method( 'POST' );
        $this->set_item_ids( $item_ids );

        $response = $this->make_http_request();

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        if ( empty( $response['ItemsResult']['Items'] ) ) {
            return array();
        }

        $items = $response['ItemsResult']['Items'];

        return $this->parse_items( $items );
    }

    private function generate_cache_key(): string {
        return 'amazon_api_' . md5( json_encode( $this->get_payload() ) );
    }

    private function get_cache( string $cache_key ): mixed {
        return get_transient( $cache_key );
    }

    private function set_cache( string $cache_key, mixed $data ): bool {
        return set_transient( $cache_key, $data, $this->cache_duration );
    }

    private function prepare_canonical_request(): string {
        $canonical_url = '';

        $canonical_url .= $this->request_method . "\n";

        $canonical_url .= $this->path . "\n" . "\n";

        $signed_headers = '';

        foreach ( $this->aws_headers as $key => $value ) {
            $signed_headers .= $key . ';';

            $canonical_url .= $key . ':' . $value . "\n";
        }

        $canonical_url .= "\n";

        $this->str_signed_header = substr( $signed_headers, 0, - 1 );

        $canonical_url .= $this->str_signed_header . "\n";

        $canonical_url .= $this->generate_hex( json_encode( $this->get_payload() ) );

        return $canonical_url;
    }

    private function prepare_string_to_sign( string $canonical_url ): string {
        $string_to_sign = '';

        $string_to_sign .= $this->hmac_algorithm . "\n";
        $string_to_sign .= $this->x_amz_date . "\n";
        $string_to_sign .= $this->current_date . '/' . $this->region_name . '/' . $this->service_name . '/' . $this->aws_request . "\n";
        $string_to_sign .= $this->generate_hex( $canonical_url );

        return $string_to_sign;
    }

    private function calculate_signature( string $string_to_sign ): string {
        $signature_key = $this->get_signature_key( $this->secret_key, $this->current_date, $this->region_name, $this->service_name );

        $signature = hash_hmac( 'sha256', $string_to_sign, $signature_key, true );

        return strtolower( bin2hex( $signature ) );
    }

    private function build_authorization_string( string $str_signature ): string {
        return $this->hmac_algorithm . ' ' . 'Credential=' . $this->access_key . '/' . $this->get_date() . '/' . $this->region_name . '/' . $this->service_name . '/' . $this->aws_request . ',' . 'SignedHeaders=' . $this->str_signed_header . ',' . 'Signature=' . $str_signature;
    }

    private function generate_hex( string $data ): string {
        return strtolower( bin2hex( hash( 'sha256', $data, true ) ) );
    }

    private function get_signature_key( string $key, string $date, string $region_name, string $service_name ): string {
        $k_secret = 'AWS4' . $key;

        $k_date = hash_hmac( 'sha256', $date, $k_secret, true );

        $k_region = hash_hmac( 'sha256', $region_name, $k_date, true );

        $k_service = hash_hmac( 'sha256', $service_name, $k_region, true );

        return hash_hmac( 'sha256', $this->aws_request, $k_service, true );
    }

    private function get_time_stamp(): string {
        return gmdate( 'Ymd\THis\Z' );
    }

    private function get_date(): string {
        return gmdate( 'Ymd' );
    }

    private function set_keys(): void {
        $this->amazon_options = $this->plugin_settings->get_plugin_settings()->amazon;
        $this->access_key     = $this->amazon_options->get_api_key();
        $this->secret_key     = $this->amazon_options->get_api_secret();
        $this->region_name    = $this->amazon_options->get_region_name();
        $this->host           = $this->amazon_options->get_host();
        $this->partner_tag    = $this->amazon_options->get_tracking_id();
    }

    private function parse_items( array $items ): array {
        $products        = array();
        $parser_strategy = $this->parser_factory->get_parser_strategy(
            $this->plugin_settings->get_plugin_settings()->amazon->use_amazon_api()
        );

        foreach ( $items as $item ) {
            $products[] = Product::create_from_api( $parser_strategy->parse( $item ) );
        }

        return $products;
    }
}
