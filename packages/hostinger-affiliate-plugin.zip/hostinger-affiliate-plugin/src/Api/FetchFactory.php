<?php
namespace Hostinger\AffiliatePlugin\Api;

use Hostinger\AffiliatePlugin\Containers\Container;

class FetchFactory {
    protected Container $container;

    public function __construct( Container $container ) {
        $this->container = $container;
    }

    public function get_fetch_strategy( bool $use_amazon_api ): AmazonFetchStrategy {
        if ( $use_amazon_api ) {
            return $this->container->get( AmazonClient::class );
        }

        return $this->container->get( ProxyClient::class );
    }
}
