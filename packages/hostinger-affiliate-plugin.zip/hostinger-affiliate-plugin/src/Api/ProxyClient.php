<?php
namespace Hostinger\AffiliatePlugin\Api;

use Hostinger\AffiliatePlugin\Admin\PluginSettings;
use Hostinger\AffiliatePlugin\Models\Product;
use Hostinger\AffiliatePlugin\Models\ProductData\ParserFactory;
use Hostinger\WpHelper\Config;
use Hostinger\WpHelper\Constants;
use Hostinger\WpHelper\Utils;
use WP_Error;
use WP_Http;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

class ProxyClient implements AmazonFetchStrategy {
    const SEARCH_ITEMS_ENDPOINT = '/v3/wordpress/plugin/amazon/search';
    const GET_ITEM_ENDPOINT     = '/v3/wordpress/plugin/amazon/product';

    private RequestsClient $requests_client;
    private Utils $utils;
    private Config $config;
    private PluginSettings $plugin_settings;
    private array $headers;
    private ParserFactory $parser_factory;

    public function __construct( RequestsClient $requests_client, Utils $utils, Config $config, PluginSettings $plugin_settings, ParserFactory $parser_factory ) {
        $this->requests_client = $requests_client;
        $this->utils           = $utils;
        $this->config          = $config;
        $this->plugin_settings = $plugin_settings;
        $this->parser_factory  = $parser_factory;

        $this->init_requests_client();
    }

    public function search_items( string $keywords ): WP_Error|array {
        $params = array(
            'domain'       => $this->utils->getHostInfo(),
            'search_query' => $keywords,
        );

        $params = array_merge( $params, $this->get_locale_data() );

        $response = $this->requests_client->get( self::SEARCH_ITEMS_ENDPOINT, $params, $this->headers );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $validation = $this->validate_response( $response );

        if ( is_wp_error( $validation ) ) {
            return $validation;
        }

        $data = $this->decode_response( $response );

        if ( empty( $data['data']['results'] ) ) {
            return array();
        }

        $products        = array();
        $parser_strategy = $this->parser_factory->get_parser_strategy(
            $this->plugin_settings->get_plugin_settings()->amazon->use_amazon_api()
        );

        usort(
            $data['data']['results'],
            function ( $a, $b ) {
                return ( $b['stars'] ?? 0 ) <=> ( $a['stars'] ?? 0 );
            }
        );

        foreach ( $data['data']['results'] as $item ) {
            $products[] = Product::create_from_api( $parser_strategy->parse( $item ) );
        }

        return $products;
    }

    public function get_item( string $asin ): WP_Error|Product|null {
        $params = array(
            'domain' => $this->utils->getHostInfo(),
            'asin'   => $asin,
        );

        $params = array_merge( $params, $this->get_locale_data() );

        $response = $this->requests_client->get( self::GET_ITEM_ENDPOINT, $params, $this->headers );

        if ( is_wp_error( $response ) ) {
            return $response;
        }
        $validation = $this->validate_response( $response );

        if ( is_wp_error( $validation ) ) {
            return $validation;
        }

        $data = $this->decode_response( $response );

        if ( empty( $data['data']['name'] ) ) {
            return null;
        }

        if ( empty( $data['data']['asin'] ) ) {
            $data['data']['asin'] = $asin;
        }

        $parser_strategy = $this->parser_factory->get_parser_strategy( $this->plugin_settings->get_plugin_settings()->amazon->use_amazon_api() );

        return Product::create_from_api( $parser_strategy->parse( $data['data'] ) );
    }

    public function get_items( array $item_ids ): array {
        $products = array();

        foreach ( $item_ids as $asin ) {
            $product = $this->get_item( $asin );

            if ( ! is_wp_error( $product ) ) {
                $products[] = $product;
            }
        }

        return $products;
    }

    private function init_requests_client(): void {
        $this->headers = array(
            Config::TOKEN_HEADER  => $this->utils->getApiToken(),
            Config::DOMAIN_HEADER => $this->utils->getHostInfo(),
        );
        $this->requests_client->set_api_url( $this->config->getConfigValue( 'base_rest_uri', Constants::HOSTINGER_REST_URI ) );
    }

    private function decode_response( array $response ): array {
        $response_body = wp_remote_retrieve_body( $response );

        if ( empty( $response_body ) ) {
            return array();
        }

        return json_decode( $response_body, true );
    }

    private function validate_response( array $response ): WP_Error|bool {
        $response_code = wp_remote_retrieve_response_code( $response );

        $data = $this->decode_response( $response );

        if ( empty( $response_code ) || $response_code !== 200 ) {
            return new WP_Error(
                'data_invalid',
                __( 'Sorry, there was a problem with request.', 'hostinger-affiliate-plugin' ),
                array(
                    'status' => WP_Http::BAD_REQUEST,
                    'errors' => $this->decode_error_message( $data ),
                )
            );
        }

        return true;
    }

    private function decode_error_message( array $data ): string {
        if ( ! isset( $data['error']['message'] ) ) {
            return '';
        }

        $error_message = $data['error']['message'];
        $input_errors  = array();

        $inputs = ! empty( $data['error']['inputs'] ) ? $data['error']['inputs'] : '';
        if ( ! empty( $inputs ) ) {
            foreach ( $inputs as $field => $errors ) {
                $input_errors[] = "$field: " . implode( ', ', $errors );
            }
        }

        return 'Error: ' . $error_message . '.' . ( ! empty( $input_errors ) ? ( 'Invalid Inputs: ' . implode( ', ', $input_errors ) ) : '' );
    }

    private function get_locale_data(): array {
        $domain = $this->plugin_settings->get_plugin_settings()->amazon->get_domain();

        return array(
            'country' => str_replace( 'amazon.', '', $domain ),
            'tld'     => $this->plugin_settings->get_plugin_settings()->amazon->get_country(),
        );
    }
}
