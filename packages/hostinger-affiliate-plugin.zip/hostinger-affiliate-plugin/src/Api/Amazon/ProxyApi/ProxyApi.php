<?php
namespace Hostinger\AffiliatePlugin\Api\Amazon\ProxyApi;

use Hostinger\AffiliatePlugin\Api\Amazon\AmazonApiInterface;
use Hostinger\AffiliatePlugin\Api\Amazon\ProxyApi\Api\ProductApi;
use Hostinger\AffiliatePlugin\Api\Amazon\ProxyApi\Api\SearchApi;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

class ProxyApi implements AmazonApiInterface {
    private Client $client;
    public function __construct( Client $client ) {
        $this->client = $client;
    }

    public function search_api(): SearchApi {
        return new SearchApi( $this->client );
    }

    public function product_api(): ProductApi {
        return new ProductApi( $this->client );
    }
}
