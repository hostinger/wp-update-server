<?php
namespace Hostinger\AffiliatePlugin\Api\Amazon\ProxyApi\Api;

use Hostinger\AffiliatePlugin\Api\Amazon\AmazonApi\Request\GetProductDataRequest;
use Hostinger\AffiliatePlugin\Api\Amazon\ProxyApi\Client;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

class ProductApi {
    private const GET_ITEM_ENDPOINT = '/v3/wordpress/plugin/amazon/product';
    private Client $client;

    public function __construct( Client $client ) {
        $this->client = $client;
    }

    public function product_data( GetProductDataRequest $request ): array|WP_Error {
        $products = array();

        foreach ( $request->get_item_ids() as $asin ) {
            $product = $this->get_product( $asin );

            if ( ! is_wp_error( $product ) ) {
                $products[] = $product;
            }
        }

        return $products;
    }

    public function get_product( string $asin ): array|WP_Error {
        $params = array(
            'asin' => $asin,
        );

        $request = $this->client->get( self::GET_ITEM_ENDPOINT, $params );

        if ( isset( $request['data']['name'] ) ) {
            if ( empty( $request['data']['asin'] ) ) {
                $request['data']['asin'] = $asin;
            }

            return $request['data'];
        }

        return $request;
    }
}
