<?php
/**
 * Items API
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Rest;

use Hostinger\AffiliatePlugin\Admin\PluginSettings;
use Hostinger\AffiliatePlugin\Api\AmazonClient;
use Hostinger\AffiliatePlugin\Errors\AmazonApiError;
use Hostinger\AffiliatePlugin\Localization\Messages;
use Hostinger\AffiliatePlugin\Repositories\Product as ProductRepository;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class for items
 */
class ItemsRoutes {
	/**
	 *
	 * Settings instance
	 *
	 * @var PluginSettings
	 */
	public PluginSettings $plugin_settings;

	/**
	 * Construct class with dependencies
	 *
	 * @param PluginSettings $plugin_settings instance.
	 */
	public function __construct( PluginSettings $plugin_settings ) {
		$this->plugin_settings = $plugin_settings;
	}

	/**
	 * @param \WP_REST_Request $request WordPress request.
	 *
	 * @return \WP_REST_Response|\AmazonApiError|\WP_Error
	 */
	public function search_items( \WP_REST_Request $request ): \WP_REST_Response|\AmazonApiError|\WP_Error {
		$parameters = $request->get_params();

		$errors = array();

		if ( empty( $parameters['keyword'] ) ) {
			$errors['keyword'] = Messages::get_missing_field_message( str_replace( '_', ' ', 'keyword' ) );
		}

		if ( ! empty( $errors ) ) {
			return new \WP_Error(
				'data_invalid',
				__( 'Sorry, there are validation errors.', 'hostinger-affiliate-plugin' ),
				array(
					'status' => \WP_Http::BAD_REQUEST,
					'errors' => $errors,
				)
			);
		}

		$settings = $this->plugin_settings->get_plugin_settings( false );

		$amazon_client = new AmazonClient( $settings->amazon );

		$amazon_client->set_resources( array( 'Images.Primary.Small' ) );

		$search_keyword = sanitize_text_field( $parameters['keyword'] );

		$amazon_response = $amazon_client->search_items( $search_keyword );

		if ( ! empty( $amazon_response['Errors'] ) ) {
			$response = new \WP_REST_Response( array( 'data' => new AmazonApiError( $amazon_response['Errors'] ) ) );

			$response->set_status( \WP_Http::BAD_REQUEST );

			return $response;
		}

		$response_array = array(
			'data' => array(
				'items' => ! empty( $amazon_response['SearchResult']['Items'] ) ? count( $amazon_response['SearchResult']['Items'] ) : 0,
				'html'  => $this->render_item_results( $amazon_response ),
			),
		);

		$response = new \WP_REST_Response( $response_array );

		$response->set_status( \WP_Http::OK );

		return $response;
	}

	/**
	 * @param \WP_REST_Request $request WordPress request.
	 *
	 * @return \WP_REST_Response
	 */
	public function validate_items( \WP_REST_Request $request ): \WP_REST_Response {
		global $wpdb;

		$parameters = $request->get_params();

		$product_repository = new ProductRepository( $wpdb );

		$errors = array();

		if ( empty( $parameters['items'] ) ) {
			$errors[] = Messages::get_missing_field_message( str_replace( '_', ' ', 'items' ) );
		}

		$items = $product_repository->clean_asin( $parameters['items'] );

		if ( empty( $product_repository->validate_asins( $items ) ) ) {
			$errors[] = Messages::get_failed_asin_validation_message();
		}

		if ( ! empty( $errors ) ) {
			return new \WP_Error(
				'data_invalid',
				__( 'Sorry, there are validation errors.', 'hostinger-affiliate-plugin' ),
				array(
					'status' => \WP_Http::BAD_REQUEST,
					'errors' => $errors,
				)
			);
		}

		try {
			$products = $product_repository->pull_products( $items );
		} catch ( \Exception $e ) {
			$errors = array(
				'data' => array( 'errors' => array( $e->getMessage() ) ),
			);

			$response = new \WP_REST_Response( $errors );

			$response->set_status( \WP_Http::BAD_REQUEST );

			return $response;
		}

		$response = new \WP_REST_Response( array( 'data' => 'OK' ) );

		$response->set_status( \WP_Http::OK );

		return $response;
	}

	/**
	 * @param array $response API response.
	 *
	 * @return string
	 */
	private function render_item_results( array $response ): string {
		if ( empty( $response['SearchResult']['Items'] ) ) {
			return '';
		}

		$content = '';

		ob_start();

		require_once __DIR__ . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . 'search-results.php';

		$content = ob_get_contents();

		ob_end_clean();

		return $content;
	}
}
