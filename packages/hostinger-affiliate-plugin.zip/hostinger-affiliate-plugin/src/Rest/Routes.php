<?php
/**
 * Rest API Routes
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Rest;

use Hostinger\AffiliatePlugin\Rest\Settings as RestSettings;
use Hostinger\AffiliatePlugin\Admin\PluginSettings as AdminSettings;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class for handling Rest Api Routes
 */
class Routes {
	/**
	 * @var Settings
	 */
	public SettingsRoutes $settings_routes;

	/**
	 * @var ItemsRoutes
	 */
	public ItemsRoutes $items_routes;

	/**
	 * @param SettingsRoutes $settings_routes Settings route class.
	 * @param ItemsRoutes    $items_routes    Items route class.
	 */
	public function __construct( SettingsRoutes $settings_routes, ItemsRoutes $items_routes ) {
		$this->settings_routes = $settings_routes;
		$this->items_routes    = $items_routes;
	}

	/**
	 * Init rest routes
	 *
	 * @return void
	 */
	public function init(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * @return void
	 */
	public function register_routes() {
		// Register Settings Rest API Routes.
		$this->register_settings_routes();

		// Register Item Rest API Routes.
		$this->register_item_routes();
	}

	/**
	 *
	 * @return void
	 */
	private function register_settings_routes(): void {
		// Return settings.
		register_rest_route(
			HOSTINGER_AFFILIATE_PLUGIN_REST_API_BASE,
			'get-settings',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this->settings_routes, 'get_settings' ),
				'permission_callback' => array( $this, 'permission_check' ),
			)
		);

		// Update settings.
		register_rest_route(
			HOSTINGER_AFFILIATE_PLUGIN_REST_API_BASE,
			'update-settings',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this->settings_routes, 'update_settings' ),
				'permission_callback' => array( $this, 'permission_check' ),
			)
		);

		// Delete settings.
		register_rest_route(
			HOSTINGER_AFFILIATE_PLUGIN_REST_API_BASE,
			'delete-settings',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this->settings_routes, 'delete_settings' ),
				'permission_callback' => array( $this, 'permission_check' ),
			)
		);
	}

	/**
	 * @return void
	 */
	private function register_item_routes(): void {
		// Return items.
		register_rest_route(
			HOSTINGER_AFFILIATE_PLUGIN_REST_API_BASE,
			'search-items',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this->items_routes, 'search_items' ),
				'permission_callback' => array( $this, 'permission_check' ),
			)
		);

		// Validate items.
		register_rest_route(
			HOSTINGER_AFFILIATE_PLUGIN_REST_API_BASE,
			'validate-items',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this->items_routes, 'validate_items' ),
				'permission_callback' => array( $this, 'permission_check' ),
			)
		);
	}
	/**
	 * @param WP_REST_Request $request WordPress rest request.
	 *
	 * @return bool
	 */
	public function permission_check( $request ): bool {
		if ( empty( is_user_logged_in() ) ) {
			return false;
		}

		// Implement custom capabilities when needed.
		return current_user_can( 'manage_options' );
	}
}
