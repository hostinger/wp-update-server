<?php
/**
 * Settings Rest API
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Rest;

use Hostinger\AffiliatePlugin\Admin\Options\PluginOptions;
use Hostinger\AffiliatePlugin\Admin\PluginSettings;
use Hostinger\AffiliatePlugin\Api\AmazonClient;
use Hostinger\AffiliatePlugin\Api\RequestsClient;
use Hostinger\AffiliatePlugin\Errors\AmazonApiError;
use Hostinger\AffiliatePlugin\Localization\Messages;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class for handling Settings Rest API
 */
class SettingsRoutes {
	/**
	 *
	 * Amazon client instance
	 *
	 * @var AmazonClient
	 */
	private AmazonClient $amazon_client;

	/**
	 * @var PluginSettings plugin settings.
	 */
	private PluginSettings $plugin_settings;

	/**
	 * Construct class with dependencies
	 *
	 * @param AmazonClient   $amazon_client instance.
	 * @param PluginSettings $plugin_settings instance.
	 */
	public function __construct( AmazonClient $amazon_client, PluginSettings $plugin_settings ) {
		$this->amazon_client   = $amazon_client;
		$this->plugin_settings = $plugin_settings;
	}

	/**
	 * Return all stored plugin settings
	 *
	 * @param WP_REST_Request $request WordPress rest request.
	 *
	 * @return \WP_REST_Response
	 */
	public function get_settings( WP_REST_Request $request ): \WP_REST_Response {
		$response = new \WP_REST_Response( $this->plugin_settings->get_plugin_settings() );

		$response->set_status( \WP_Http::OK );

		return $response;
	}

	/**
	 *
	 * @param \WP_REST_Request $request WordPress rest request.
	 *
	 * @return \WP_REST_Response|\AmazonApiError|\WP_Error
	 *
	 */
	public function update_settings( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$settings = $this->plugin_settings->get_plugin_settings( false );

		$new_settings = array();

		$parameters = $request->get_params();

		$errors = array();

		foreach ( $settings->amazon->to_array() as $field_key => $field_value ) {
			if ( empty( $parameters[ $field_key ] ) ) {
				$errors[ $field_key ] = Messages::get_missing_field_message( str_replace( '_', ' ', $field_key ) );
			} else {
				$new_settings['amazon'][ $field_key ] = sanitize_text_field( $parameters[ $field_key ] );
			}
		}

		if ( ! empty( $settings->amazon->get_api_secret() ) ) {
			$new_settings['amazon']['api_secret'] = $settings->amazon->get_api_secret();
		}

		$new_settings = new PluginOptions( $new_settings );

		if ( ! empty( $errors ) ) {
			return new \WP_Error(
				'data_invalid',
				__( 'Sorry, you are not allowed to do that.', 'hostinger-affiliate-plugin' ),
				array(
					'status' => \WP_Http::BAD_REQUEST,
					'errors' => $errors,
				)
			);
		}

		$amazon_response = $this->amazon_client->search_items( 'Test' );

		if ( ! empty( $amazon_response['Errors'] ) ) {
			$response = new \WP_REST_Response( array( 'data' => new AmazonApiError( $amazon_response['Errors'] ) ) );

			$response->set_status( \WP_Http::BAD_REQUEST );

			return $response;
		}

		// Set Amazon API status as connected.
		$new_settings->set_connection_status( PluginOptions::STATUS_CONNECTED );

		$response = new \WP_REST_Response( array( 'data' => $this->plugin_settings->save_plugin_settings( $new_settings )->to_array() ) );

		$response->set_status( \WP_Http::OK );

		return $response;
	}

	/**
	 * @param \WP_REST_Request $request WordPress rest request.
	 *
	 * @return \WP_REST_Response
	 */
	public function delete_settings( \WP_REST_Request $request ): \WP_REST_Response {
		$settings = $this->plugin_settings->get_plugin_settings( false );

		$settings->amazon->delete_credentials();

		$settings->set_connection_status( PluginOptions::STATUS_DISCONNECTED );

		$response = new \WP_REST_Response( array( 'data' => $this->plugin_settings->save_plugin_settings( $settings )->to_array() ) );

		$response->set_status( \WP_Http::OK );

		return $response;
	}
}