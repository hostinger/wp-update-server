<?php
/**
 * ProductInterface class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Repositories;

use Hostinger\AffiliatePlugin\Models\Product as ProductModel;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

interface ProductInterface {
	/**
	 * @param ProductModel $product product model.
	 *
	 * @return mixed
	 */
	public function insert( ProductModel $product );
}
