<?php

namespace Hostinger\AffiliatePlugin\Repositories;

use Hostinger\AffiliatePlugin\Admin\PluginSettings;
use Hostinger\AffiliatePlugin\Api\FetchFactory;
use Hostinger\AffiliatePlugin\Models\Product;
use Hostinger\AffiliatePlugin\Models\Product as ProductModel;
use Hostinger\AffiliatePlugin\Api\AmazonClient;
use Hostinger\AffiliatePlugin\Amplitude\Events as AmplitudeEvents;
use Exception;
use WP_Error;
use wpdb;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

class ProductRepository implements RepositoryInterface {
    private wpdb $db;
    private AmazonClient $amazon_client;
    private AmplitudeEvents $amplitude_events;
    private string $table_name;
    private PluginSettings $plugin_settings;
    private FetchFactory $fetch_factory;

    public function __construct(
        wpdb $wpdb,
        AmazonClient $amazon_client,
        AmplitudeEvents $amplitude_events,
        PluginSettings $plugin_settings,
        FetchFactory $fetch_factory
    ) {
        $this->db               = $wpdb;
        $this->amazon_client    = $amazon_client;
        $this->amplitude_events = $amplitude_events;
        $this->table_name       = $this->db->prefix . 'hostinger_affiliate_products';
        $this->plugin_settings  = $plugin_settings;
        $this->fetch_factory    = $fetch_factory;
    }

    public function get_by_asins( array $asins ): array {
        $sql = 'SELECT * FROM `' . $this->table_name . '` WHERE `asin` IN (' . implode(
            ', ',
            array_fill( 0, count( $asins ), '%s' )
        ) . ')';

        $query = call_user_func_array( array( $this->db, 'prepare' ), array_merge( array( $sql ), $asins ) );

        $results = $this->db->get_results( $query, ARRAY_A );

        if ( empty( $results ) ) {
            return array();
        }

        return array_map(
            function ( $item ) {
                return new ProductModel( $item );
            },
            $results
        );
    }

    public function insert( array $fields ): bool {
        return ! empty( $this->db->insert( $this->table_name, $fields ) );
    }

    public function clean_asin( string $asin ): array {
        $asin = trim( $asin );

        $asin = str_replace( ' ', '', $asin );

        return array_filter( explode( ',', $asin ) );
    }

    public function find_missing_products( array $products, array $asins ): array {
        if ( empty( $products ) ) {
            return $asins;
        }

        $product_map = array();

        foreach ( $products as $product ) {
            $product_map[ $product->get_asin() ] = true;
        }

        $missing_products = array();

        foreach ( $asins as $asin ) {
            if ( ! isset( $product_map[ $asin ] ) ) {
                $missing_products[] = $asin;
            }
        }

        return $missing_products;
    }

    /**
     * @throws Exception
     */
    public function pull_products( array $asins, string $layout ): array {
        $products = array();

        $products_in_db = $this->get_by_asins( $asins );

        $missing_products = $this->find_missing_products( $products_in_db, $asins );

        if ( ! empty( $products_in_db ) ) {
            $products = $products_in_db;
        }

        if ( ! empty( $missing_products ) ) {
            $fetched_products = $this->fetch_products_from_api( $missing_products, $layout );

            if ( ! empty( $fetched_products ) ) {
                foreach ( $fetched_products as $product ) {
                    $products[] = $product;

                    if ( $product instanceof Product ) {
                        $this->insert( $product->to_array() );
                    }
                }
            }
        }

        return $products;
    }

    public function validate_asins( array $asins ): bool {
        if ( empty( $asins ) ) {
            return false;
        }

        $valid = true;

        foreach ( $asins as $asin ) {
            if ( ! preg_match( '/^[A-Z0-9]{10}$/', $asin ) ) {
                $valid = false;
            }
        }

        return $valid;
    }

    public function format_asins( array $products ) {
        $formatted_asins = array();

        if ( empty( $products ) ) {
            return $formatted_asins;
        }

        foreach ( $products as $product ) {
            $formatted_asins[ $product->get_asin() ] = array_intersect_key(
                $product->to_array(),
                array_flip( array( 'asin', 'title', 'image_url' ) )
            );
        }

        return $formatted_asins;
    }

    /**
     * @throws Exception
     */
    public function fetch_products_from_api( array $asins, string $layout = '' ): array {
        $fetch_strategy = $this->fetch_factory->get_fetch_strategy(
            $this->plugin_settings->get_plugin_settings()->amazon->use_amazon_api()
        );

        $products = $fetch_strategy->get_items( $asins );

        if ( is_wp_error( $products ) ) {
            $this->handle_amazon_errors( $products );
        }

        $this->amplitude_events->affiliate_created( $layout );

        return $products;
    }

    public function create_from_api( ProductModel $product ): ProductModel {
        $product->set_updated_at( $product->get_created_at() );

        $this->insert( $product->to_array() );

        return $product;
    }


    /**
     * @throws Exception
     */
    private function handle_amazon_errors( WP_Error $error ): void {
        $reversed_error_messages = implode( ', ', array_reverse( $error->get_error_messages() ) );

        if ( current_user_can( 'administrator' ) ) {
            $formatted_errors = $reversed_error_messages;
        } else {
            $formatted_errors = __(
                'There is an issue displaying Amazon products. Please contact the administrator to check that.',
                'hostinger-affiliate-plugin'
            );
        }

        throw new Exception( $formatted_errors );
    }

    public function update( $data, $where ): bool {
        $data = array_diff_key( $data, array_flip( array( 'id', 'created_at' ) ) );

        if ( empty( $data ) ) {
            return false;
        }

        return $this->db->update(
            $this->table_name,
            $data,
            $where
        );
    }

    public function get_by_updated_at( string $date, int $limit = 10 ): array {
        $sql = 'SELECT * FROM `'
               . $this->table_name
               . '` WHERE `updated_at` < %s ORDER BY `updated_at` ASC LIMIT 0, %d';

        $query = $this->db->prepare( $sql, $date, $limit );

        $results = $this->db->get_results( $query, ARRAY_A );

        if ( empty( $results ) ) {
            return array();
        }

        return array_map(
            function ( $item ) {
                return new ProductModel( $item );
            },
            $results
        );
    }
}
