<?php

namespace Hostinger\AffiliatePlugin;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

use Hostinger\AffiliatePlugin\Admin\Menus;
use Hostinger\AffiliatePlugin\Containers\Container;
use Hostinger\AffiliatePlugin\Rest\Routes;
use Hostinger\AffiliatePlugin\Setup\Assets;
use Hostinger\AffiliatePlugin\Setup\Blocks;
use Hostinger\AffiliatePlugin\Setup\Cpts;
use Hostinger\AffiliatePlugin\Setup\Localization;
use Hostinger\AffiliatePlugin\Setup\Updates;
use Hostinger\AffiliatePlugin\Amplitude\Events as AmplitudeEvents;
use Hostinger\AffiliatePlugin\Services\ProductUpdateService;
use wpdb;

class Boot {
    private static ?Boot $instance = null;

    public static function get_instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function plugins_loaded(): void {
        global $wpdb;

        $container = new Container();

        $container->set( 'wpdb', fn() => $wpdb );

        $container->set( Container::class, fn() => $container );

        $menus = $container->get( Menus::class );
        $menus->init();

        $cpts = $container->get( Cpts::class );
        $cpts->init();

        $updates = $container->get( Updates::class );
        $updates->updates();

        $assets = $container->get( Assets::class );
        $assets->init();

        $localization = $container->get( Localization::class );
        $localization->init();

        $amplitude_events = $container->get( AmplitudeEvents::class );
        $amplitude_events->init();

        $rest_routes = $container->get( Routes::class );
        $rest_routes->init();

        $blocks = $container->get( Blocks::class );
        $blocks->init();

        $product_update_service = $container->get( ProductUpdateService::class );
        $product_update_service->init();
    }
}
