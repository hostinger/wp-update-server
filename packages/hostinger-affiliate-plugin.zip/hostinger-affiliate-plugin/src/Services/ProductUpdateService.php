<?php

namespace Hostinger\AffiliatePlugin\Services;

use Hostinger\AffiliatePlugin\Admin\Options\PluginOptions;
use Hostinger\AffiliatePlugin\Admin\PluginSettings;
use Hostinger\AffiliatePlugin\Repositories\ProductRepository;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

class ProductUpdateService {
    private ProductRepository $product_repository;
    private PluginSettings $plugin_settings;

    public function __construct( ProductRepository $product_repository, PluginSettings $plugin_settings ) {
        $this->product_repository = $product_repository;
        $this->plugin_settings    = $plugin_settings;
    }

    public function init(): void {
        add_action( 'hostinger_affiliate_product_update', array( $this, 'handle_product_update' ) );
    }

    public function handle_product_update(): bool {
        $settings = $this->plugin_settings->get_plugin_settings();

        $connection_status = $settings->get_connection_status();
        if ( $connection_status !== PluginOptions::STATUS_CONNECTED ) {
            return false;
        }

        // Getting outdated products.
        $past_seven_days = wp_date( 'Y-m-d H:i:s', strtotime( '-7 days' ) );
        $products        = $this->product_repository->get_by_updated_at( $past_seven_days, 10 );
        if ( empty( $products ) ) {
            return false;
        }

        // Prepare outdated product ASINs.
        $asins = array();
        foreach ( $products as $product ) {
            $asins[] = $product->get_asin();
        }

        // Pull outdated products from Amazon API.
        try {
            $products = $this->product_repository->fetch_products_from_api( $asins );
        } catch ( \Exception $e ) {
            error_log( 'Hostinger Amazon Affiliate Connector: Error syncing products from Amazon API - ' . $e->getMessage() );
        }

        if ( empty( $products ) ) {
            return false;
        }

        // Update outdated products in DB.
        foreach ( $products as $product ) {
            $product_data = $product->to_array();
            $where        = array(
                'asin' => $product_data['asin'],
            );
            $this->product_repository->update( $product_data, $where );
        }

        return true;
    }
}
