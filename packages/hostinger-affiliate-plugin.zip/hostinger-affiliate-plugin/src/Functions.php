<?php
/**
 * Functions class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Plugin functions
 */
class Functions {

	/**
	 * Check if plugin is active
	 *
	 * @param string $plugin_slug plugin name.
	 *
	 * @return bool
	 */
	public static function is_plugin_active( $plugin_slug ): bool {
		if ( empty( $plugin_slug ) ) {
			return false;
		}

		$active_plugins = (array) get_option( 'active_plugins', array() );
		foreach ( $active_plugins as $active_plugin ) {
			if ( strpos( $active_plugin, $plugin_slug . '.php' ) !== false ) {
				return true;
			}
		}

		return false;
	}
}
