<?php
/**
 * Menus class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Admin;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class for registering menus
 */
class Menus {
	/**
	 * Settings instance
	 *
	 * @var PluginSettings
	 */
	public PluginSettings $plugin_settings;

	/**
	 * Construct class with dependencies
	 *
	 * @param PluginSettings $plugin_settings instance.
	 */
	public function __construct( PluginSettings $plugin_settings ) {
		$this->plugin_settings = $plugin_settings;
	}

	/**
	 * Init menus
	 */
	public function init(): void {
		add_action( 'hostinger_affiliate_plugin_tab_view', array( $this, 'render_plugin_content' ) );
	}


	/**
	 * Render Vue.js wrapper, pass initial plugin settings as a prop
	 *
	 * @return void
	 */
	public function render_plugin_content(): void {
		?>
		<div id="affiliatePluginApp" class="affiliatePluginApp">
			<Home
					:initial-settings="<?php echo htmlspecialchars( json_encode( $this->plugin_settings->get_plugin_settings()->to_array() ) ); ?>">
			</Home>
		</div>
		<?php
	}
}
