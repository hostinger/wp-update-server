<?php
/**
 * Product table class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Shortcodes;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Product table class
 */
class ProductTableShortcode extends Shortcode {
	/**
	 * @param ShortcodeManager $shortcode_manager Shortcode manager object.
	 */
	public function __construct( ShortcodeManager $shortcode_manager ) {
		parent::__construct( $shortcode_manager );
	}

	/**
	 * @return string
	 */
	public function render(): string {
		return 'table template';
	}
}
