<?php
/**
 * Shortcode class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Shortcodes;

use Hostinger\AffiliatePlugin\Shortcodes\ShortcodeManager;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Shortcode class
 */
class ProductCardShortcode extends Shortcode {
	/**
	 * @param ShortcodeManager $shortcode_manager Shortcode manager object.
	 */
	public function __construct( ShortcodeManager $shortcode_manager ) {
		parent::__construct( $shortcode_manager );
	}

	/**
	 * @return string
	 */
	public function render(): string {
		$atts = $this->shortcode_manager->get_atts();

		if ( empty( $atts['products'] ) ) {
			return __( 'Products not fetched from DB and/or API. Please check debug logs.', 'hostinger-affiliate-plugin' );
		}

		ob_start();

		require __DIR__ . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . 'product-card.php';

		$content = ob_get_contents();

		ob_end_clean();

		return $content;
	}
}
