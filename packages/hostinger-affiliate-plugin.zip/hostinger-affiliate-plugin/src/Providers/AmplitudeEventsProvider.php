<?php

namespace Hostinger\AffiliatePlugin\Providers;

use Hostinger\AffiliatePlugin\Amplitude\Events;
use Hostinger\AffiliatePlugin\Containers\Container;

if ( ! defined( 'ABSPATH' ) ) {
    die;
}

class AmplitudeEventsProvider implements ProviderInterface {
    public function register( Container $container ): void {
        $container->set(
            Events::class,
            function () use ( $container ) {
                return new Events();
            }
        );

        $amplitude_events = $container->get( Events::class );
        $amplitude_events->init();
    }
}
