Changelog
=========
1.0.2 (2023-11-28)
- MVP version of the plugin
