Changelog
=========
1.0.2 (2023-11-28)
- MVP version of the plugin

1.0.3 (2023-11-30)
- Fixed binding / product group item info sync from Amazon API
- Added different text label for 'Prime Videos' type items
- Added translations
- Added amplitude events

1.0.4 (2023-12-07)
- Added feature to overwrite title and description
- Added feature to limit title, description and description items

1.0.5 (2024-01-09)
- Lists functionality
- Table list page in admin