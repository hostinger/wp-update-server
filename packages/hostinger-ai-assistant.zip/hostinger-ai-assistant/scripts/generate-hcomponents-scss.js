const fs = require('fs');
const path = require('path');

const sourcePath = path.join(__dirname, '../node_modules/@hostinger/hcomponents/dist/style.css');
const targetDir = path.join(__dirname, '../vue-frontend/src/styles');
const targetPath = path.join(targetDir, 'hcomponents.scss');

// Check if the target file already exists
fs.access(targetPath, fs.constants.F_OK, (err) => {
  if (!err) {
    console.log('hcomponents.scss file already exists, no action taken.');
    return;
  }

  // Create the target file if it doesn't exist
  fs.open(targetPath, 'w', (err, fd) => {
    if (err) {
      console.error('Error creating file:', err);
      return;
    }

    // Copy the source file to the target path
    fs.copyFile(sourcePath, targetPath, (err) => {
      if (err) {
        console.error('Error copying file:', err);
      } else {
        console.log('File copied and renamed to hcomponents.scss successfully');
      }
    });
  });
});