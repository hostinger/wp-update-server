/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!******************************************!*\
  !*** ./src/scripts/hostinger-buttons.js ***!
  \******************************************/
document.addEventListener("DOMContentLoaded", function () {
  var link_id = 'hostinger_add_new_ai_post';
  var buttonText = hostingerAiAssistant.add_new_with_ai;
  var buttonLink = hostingerAiAssistant.tabUrl;
  var link_html = "<a id=\"".concat(link_id, "\" class=\"components-button is-primary\" href=\"").concat(buttonLink, "\" >").concat(buttonText, "</a>");
  var editorEl = document.getElementById('editor');
  if (!editorEl) {
    return;
  }
  var unsubscribe = wp.data.subscribe(function () {
    setTimeout(function () {
      if (!document.getElementById(link_id)) {
        var toolbalEl = editorEl.querySelector('.edit-post-header__toolbar .edit-post-header__center');
        if (toolbalEl instanceof HTMLElement && typeof link_html !== 'undefined') {
          toolbalEl.insertAdjacentHTML('beforeend', link_html);
        }
      }
    }, 1);
  });
  // unsubscribe is a function - it's not used right now
  // but in case you'll need to stop this link from being reappeared at any point you can just call unsubscribe();
});
/******/ })()
;